// types/index.ts — Types principaux de la plateforme

export type UserRole = 'admin' | 'directeur' | 'responsable_elevage' | 'veterinaire' | 'technicien_iot'

export type AnimalSex = 'M' | 'F'

export type AnimalStatus = 
  | 'actif' 
  | 'gestante' 
  | 'allaitante' 
  | 'malade' 
  | 'quarantaine' 
  | 'vendu' 
  | 'mort'

export type AnimalBreed = 'Ouled Djellal' | 'Hamra' | 'Rembi'

export interface Animal {
  id: string
  ear_tag: string           // Ex: EOI-0001
  rfid_tag?: string
  name?: string
  breed: AnimalBreed
  sex: AnimalSex
  birth_date: string
  mother_id?: string
  father_id?: string
  pen_id: string            // Bergerie A/B/C
  status: AnimalStatus
  current_weight_kg: number
  purchase_price_dzd?: number
  ai_risk_score: number     // 0-100
  created_at: string
  updated_at: string
}

export type HealthRecordType = 
  | 'vaccination' 
  | 'traitement' 
  | 'visite_veterinaire'
  | 'chirurgie' 
  | 'diagnostic' 
  | 'deces' 
  | 'quarantaine'

export interface HealthRecord {
  id: string
  animal_id: string
  type: HealthRecordType
  date: string
  diagnosis?: string
  treatment?: string
  medication?: string
  dosage?: string
  vet_id?: string
  cost_dzd?: number
  follow_up_date?: string
  resolved: boolean
  notes?: string
  created_at: string
}

export type ReproStatus = 
  | 'chaleur_detectee' 
  | 'saillie' 
  | 'gestation_confirmee'
  | 'gestation_avancee' 
  | 'agnelage' 
  | 'avortement' 
  | 'non_gestante'

export interface Reproduction {
  id: string
  female_id: string
  male_id?: string
  heat_date?: string
  mating_date?: string
  gestation_start?: string
  expected_birth?: string
  actual_birth?: string
  litter_size?: number
  male_lambs?: number
  female_lambs?: number
  stillborn: number
  status: ReproStatus
  notes?: string
  created_at: string
}

export type SensorType = 
  | 'temperature' 
  | 'humidite' 
  | 'eau_consommation' 
  | 'activite'
  | 'poids_bascule' 
  | 'co2' 
  | 'lumiere' 
  | 'solaire_production'

export interface IoTSensor {
  id: string
  sensor_code: string
  type: SensorType
  location: string
  animal_id?: string
  active: boolean
  threshold_min?: number
  threshold_max?: number
  unit?: string
}

export interface IoTReading {
  id: string
  sensor_id: string
  timestamp: string
  value: number
  anomaly_flag: boolean
  anomaly_score?: number
}

export interface Alert {
  id: string
  severity: 'critique' | 'eleve' | 'modere' | 'info'
  module: 'sante' | 'iot' | 'reproduction' | 'hydroponie' | 'energie' | 'nutrition' | 'finance' | 'ia' | 'systeme'
  title: string
  message: string
  animal_id?: string
  sensor_id?: string
  ai_confidence?: number
  resolved: boolean
  resolved_by?: string
  resolved_at?: string
  created_at: string
}

export interface SolarRecord {
  id: string
  date: string
  kwh_produced: number
  kwh_consumed: number
  kwh_surplus: number
  peak_power_kw: number
  savings_dzd: number
  autonomy_pct: number
  weather_condition?: string
}

export interface HydroCycle {
  id: string
  cycle_number: number
  start_date: string
  expected_end_date?: string
  actual_end_date?: string
  tray_count: number
  seed_qty_kg?: number
  water_used_liters?: number
  yield_kg?: number
  cost_dzd?: number
  status: 'en_cours' | 'termine' | 'incident'
  notes?: string
}

export type ProductType = 
  | 'viande_ovine' 
  | 'reproducteur_male' 
  | 'reproducteur_femelle'
  | 'fourrage' 
  | 'laine' 
  | 'fumier' 
  | 'autre'

export interface Sale {
  id: string
  date: string
  product_type: ProductType
  quantity: number
  unit: string
  unit_price_dzd: number
  total_dzd: number
  buyer_name?: string
  invoice_number?: string
  created_at: string
}

export interface DashboardKPIs {
  cheptel_total: number
  cheptel_variation: number
  taux_fertilite: number
  fertilite_variation: number
  taux_mortalite: number
  mortalite_variation: number
  ca_mensuel_dzd: number
  ca_variation: number
  marge_brute_pct: number
  alertes_actives: number
  alertes_critiques: number
  energie_autonomie_pct: number
  hydro_stock_jours: number
  cout_ration_jour_dzd: number
}

export interface FeedProfile {
  id: string
  name: string
  description?: string
  daily_ration_kg: number
  cost_per_kg_dzd: number
  ingredients: Array<{
    name: string
    qty_kg: number
    cost: number
  }>
}

export interface Profile {
  id: string
  full_name: string
  role: UserRole
  phone?: string
  avatar_url?: string
  created_at: string
  last_active?: string
}
