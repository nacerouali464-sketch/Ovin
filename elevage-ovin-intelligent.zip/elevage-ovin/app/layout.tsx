// app/layout.tsx
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Élevage Ovin Intelligent | Sidi Bel Abbès',
  description: 'Plateforme de pilotage intelligente pour élevage ovin — IoT, IA, Hydroponie, Énergie Solaire',
  manifest: '/manifest.json',
  themeColor: '#0F6E56',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  )
}
