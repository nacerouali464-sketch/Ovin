'use client'
// app/dashboard/hydroponie/page.tsx

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const cycles = [
  { num: 'C-01', debut: '01/01/2025', fin: '08/01/2025', plateaux: 840, rendement: '588 kg', cout: '12 600 DZD', statut: 'termine' },
  { num: 'C-02', debut: '09/01/2025', fin: '16/01/2025', plateaux: 840, rendement: '602 kg', cout: '12 600 DZD', statut: 'termine' },
  { num: 'C-03', debut: '17/01/2025', fin: '24/01/2025', plateaux: 840, rendement: '594 kg', cout: '12 600 DZD', statut: 'termine' },
  { num: 'C-04', debut: '25/01/2025', fin: '01/02/2025', plateaux: 840, rendement: 'En cours...', cout: '12 600 DZD', statut: 'en_cours' },
  { num: 'C-11', debut: '14/01/2025', fin: '22/01/2025', plateaux: 1000, rendement: 'En cours...', cout: '15 000 DZD', statut: 'en_cours' },
]

const productionData = [
  { sem: 'S1', production: 588 },
  { sem: 'S2', production: 602 },
  { sem: 'S3', production: 594 },
  { sem: 'S4', production: 0 },
]

export default function HydroponiePage() {
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Hydroponie — 500 m²</h1>
          <p className="text-sm text-gray-500 mt-0.5">Production de fourrage vert en cycles de 7 à 10 jours</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-outline text-sm">📊 Rapport cycles</button>
          <button className="btn-primary text-sm">+ Lancer nouveau cycle</button>
        </div>
      </div>

      <div className="grid grid-cols-5 gap-4 mb-6">
        {[
          { label: 'PRODUCTION MENSUELLE', value: '1 680 kg', sub: '3 cycles complets', color: 'text-green-700' },
          { label: 'STOCK RESTANT', value: '2,8 jours', sub: '⚠ Seuil critique', color: 'text-red-600' },
          { label: 'COÛT / KG PRODUIT', value: '21 DZD', sub: '-62% vs marché', color: 'text-green-700' },
          { label: 'PLATEAUX ACTIFS', value: '840/1000', sub: '84% capacité', color: 'text-amber-600' },
          { label: 'EAU CONSOMMÉE/JOUR', value: '1 240 L', sub: 'Optimisé IA', color: 'text-green-700' },
        ].map((k, i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-label">{k.label}</div>
            <div className={`text-lg font-medium ${k.color}`}>{k.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="card">
          <div className="font-medium text-sm mb-4">Production hebdomadaire (kg)</div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={productionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="sem" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Line type="monotone" dataKey="production" stroke="#1D9E75" strokeWidth={2} dot={{ fill: '#1D9E75' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <div className="font-medium text-sm mb-4">Cycle en cours — C-04 (J6/J8)</div>
          <div className="space-y-3">
            {[
              { label: 'Avancement', value: '75%', pct: 75, color: '#1D9E75' },
              { label: 'Humidité chambre', value: '72%', pct: 72, color: '#1D9E75' },
              { label: 'Température', value: '22°C', pct: 55, color: '#1D9E75' },
              { label: 'Germination', value: '94%', pct: 94, color: '#1D9E75' },
            ].map((p, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs mb-1">
                  <span>{p.label}</span>
                  <span className="font-medium" style={{ color: p.color }}>{p.value}</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${p.pct}%`, backgroundColor: p.color }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card overflow-hidden p-0">
        <div className="p-4 border-b border-gray-100 font-medium text-sm">Historique des cycles</div>
        <table className="data-table">
          <thead>
            <tr className="bg-gray-50">
              <th>Cycle</th>
              <th>Début</th>
              <th>Fin</th>
              <th>Plateaux</th>
              <th>Rendement</th>
              <th>Coût</th>
              <th>Statut</th>
            </tr>
          </thead>
          <tbody>
            {cycles.map((c, i) => (
              <tr key={i}>
                <td className="font-medium text-green-700">{c.num}</td>
                <td className="text-xs text-gray-500">{c.debut}</td>
                <td className="text-xs text-gray-500">{c.fin}</td>
                <td className="text-xs">{c.plateaux}</td>
                <td className="text-sm font-medium">{c.rendement}</td>
                <td className="text-xs">{c.cout}</td>
                <td>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${c.statut === 'termine' ? 'badge-green' : 'badge-amber'}`}>
                    {c.statut === 'termine' ? '✓ Terminé' : '⏳ En cours'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
