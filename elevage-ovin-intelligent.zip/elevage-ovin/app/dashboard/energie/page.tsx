'use client'
// app/dashboard/energie/page.tsx

import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

const productionJour = [
  { heure: '6h', prod: 15, conso: 18 },
  { heure: '7h', prod: 45, conso: 22 },
  { heure: '8h', prod: 85, conso: 25 },
  { heure: '9h', prod: 140, conso: 28 },
  { heure: '10h', prod: 210, conso: 30 },
  { heure: '11h', prod: 265, conso: 32 },
  { heure: '12h', prod: 312, conso: 35 },
  { heure: '13h', prod: 298, conso: 38 },
  { heure: '14h', prod: 280, conso: 36 },
]

const productionSemaine = [
  { jour: 'Lun', prod: 295, conso: 195, eco: 9000 },
  { jour: 'Mar', prod: 312, conso: 198, eco: 9360 },
  { jour: 'Mer', prod: 280, conso: 190, eco: 8400 },
  { jour: 'Jeu', prod: 265, conso: 185, eco: 7950 },
  { jour: 'Ven', prod: 308, conso: 200, eco: 9240 },
  { jour: 'Sam', prod: 320, conso: 188, eco: 9600 },
  { jour: 'Dim', prod: 290, conso: 175, eco: 8700 },
]

export default function EnergiePage() {
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Énergie Solaire — 80 kWc</h1>
          <p className="text-sm text-gray-500 mt-0.5">Toiture principale · 320 panneaux · Production & autonomie temps réel</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-outline text-sm">📊 Rapport énergie</button>
          <button className="btn-outline text-sm">📥 Export données</button>
        </div>
      </div>

      <div className="grid grid-cols-5 gap-4 mb-6">
        {[
          { label: 'PRODUCTION AUJOURD\'HUI', value: '312 kWh', sub: 'Pic à 65 kW à 12h', color: 'text-green-700' },
          { label: 'CONSOMMATION', value: '198 kWh', sub: 'Dont 42 kWh hydro', color: 'text-amber-600' },
          { label: 'SURPLUS RÉSEAU', value: '218 kWh', sub: '63% de la prod', color: 'text-green-700' },
          { label: 'AUTONOMIE', value: '85%', sub: 'Objectif 90%', color: 'text-green-700' },
          { label: 'ÉCONOMIES AUJOURD\'HUI', value: '9 360 DZD', sub: '~280 000 DZD/mois', color: 'text-green-700' },
        ].map((k, i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-label">{k.label}</div>
            <div className={`text-lg font-medium ${k.color}`}>{k.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        <div className="card">
          <div className="font-medium text-sm mb-4">Courbe de production aujourd'hui (kWh cumulé)</div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={productionJour}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="heure" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Area type="monotone" dataKey="prod" name="Production" stroke="#1D9E75" fill="#E1F5EE" strokeWidth={2} />
              <Area type="monotone" dataKey="conso" name="Consommation" stroke="#BA7517" fill="#FAEEDA" strokeWidth={1.5} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="font-medium text-sm mb-4">Production & économies — 7 derniers jours</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={productionSemaine}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="jour" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Bar dataKey="prod" name="Prod (kWh)" fill="#9FE1CB" radius={[3,3,0,0]} />
              <Bar dataKey="conso" name="Conso (kWh)" fill="#FAC775" radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="card">
          <div className="font-medium text-sm mb-4">Répartition consommation</div>
          <div className="space-y-3">
            {[
              { label: 'Pompage eau', value: '42 kWh', pct: 21, color: '#1D9E75' },
              { label: 'Ventilation bergeries', value: '38 kWh', pct: 19, color: '#0F6E56' },
              { label: 'Éclairage', value: '28 kWh', pct: 14, color: '#9FE1CB' },
              { label: 'Hydroponie', value: '42 kWh', pct: 21, color: '#BA7517' },
              { label: 'Bureaux & divers', value: '48 kWh', pct: 25, color: '#888' },
            ].map((c, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs mb-1">
                  <span>{c.label}</span>
                  <span className="font-medium">{c.value}</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${c.pct * 4}%`, backgroundColor: c.color }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="font-medium text-sm mb-4">Performance mensuelle</div>
          <div className="space-y-3">
            {[
              { label: 'Production totale Jan', value: '8 680 kWh', color: 'text-green-700' },
              { label: 'Consommation totale Jan', value: '5 580 kWh', color: 'text-amber-600' },
              { label: 'Surplus injecté réseau', value: '3 100 kWh', color: 'text-green-700' },
              { label: 'Économies Jan', value: '280 800 DZD', color: 'text-green-700' },
              { label: 'CO₂ évité', value: '4,1 tonnes', color: 'text-green-700' },
              { label: 'Taux autonomie moyen', value: '85,2%', color: 'text-green-700' },
            ].map((s, i) => (
              <div key={i} className="flex justify-between items-center py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">{s.label}</span>
                <span className={`text-sm font-medium ${s.color}`}>{s.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="font-medium text-sm mb-4">Prévisions météo & production</div>
          <div className="space-y-2">
            {[
              { jour: 'Aujourd\'hui', meteo: '☀️ Ensoleillé', prev: '310-330 kWh', ok: true },
              { jour: 'Demain', meteo: '☀️ Ensoleillé', prev: '340-360 kWh', ok: true },
              { jour: 'Après-demain', meteo: '⛅ Nuageux', prev: '180-220 kWh', ok: null },
              { jour: 'Dans 3 jours', meteo: '🌥 Couvert', prev: '120-150 kWh', ok: false },
              { jour: 'Dans 4 jours', meteo: '☀️ Ensoleillé', prev: '300-320 kWh', ok: true },
            ].map((p, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
                <div>
                  <div className="text-xs font-medium">{p.jour}</div>
                  <div className="text-xs text-gray-400">{p.meteo}</div>
                </div>
                <span className={`text-xs font-medium ${p.ok === true ? 'text-green-700' : p.ok === null ? 'text-amber-600' : 'text-red-500'}`}>
                  {p.prev}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
