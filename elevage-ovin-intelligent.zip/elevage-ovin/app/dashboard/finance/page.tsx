'use client'
// app/dashboard/finance/page.tsx

import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const caData = [
  { mois: 'Jan', ca: 980, opex: 680, marge: 300 },
  { mois: 'Fév', ca: 1050, opex: 695, marge: 355 },
  { mois: 'Mar', ca: 1120, opex: 710, marge: 410 },
  { mois: 'Avr', ca: 1080, opex: 690, marge: 390 },
  { mois: 'Mai', ca: 1420, opex: 740, marge: 680 },
]

const projections = [
  { annee: 'A1', ca: 15.2, tetes: 500 },
  { annee: 'A2', ca: 28.4, tetes: 1200 },
  { annee: 'A3', ca: 45.8, tetes: 2000 },
  { annee: 'A4', ca: 62.1, tetes: 2800 },
  { annee: 'A5', ca: 78.25, tetes: 3500 },
]

const ventes = [
  { date: '28/01/2025', produit: 'Fourrage hydroponique', qte: '840 kg', prix: '85 DZD/kg', total: '71 400 DZD', acheteur: 'M. Hadj Ahmed' },
  { date: '22/01/2025', produit: 'Reproducteur mâle', qte: '2 têtes', prix: '65 000 DZD/tête', total: '130 000 DZD', acheteur: 'Élevage Benali' },
  { date: '15/01/2025', produit: 'Viande ovine', qte: '485 kg', prix: '2 800 DZD/kg', total: '1 358 000 DZD', acheteur: 'Abattoir SBA' },
  { date: '10/01/2025', produit: 'Laine brute', qte: '120 kg', prix: '450 DZD/kg', total: '54 000 DZD', acheteur: 'Coopérative Oran' },
]

export default function FinancePage() {
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Finance — Tableau de bord</h1>
          <p className="text-sm text-gray-500 mt-0.5">Exercice 2025 · Devise DZD</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-outline text-sm">📊 Rapport PDF</button>
          <button className="btn-outline text-sm">📥 Export Excel</button>
        </div>
      </div>

      {/* KPI Finance */}
      <div className="grid grid-cols-5 gap-4 mb-6">
        {[
          { label: 'CA MENSUEL', value: '1,42 M DZD', sub: '↑ +8%', color: 'text-green-700' },
          { label: 'OPEX MENSUEL', value: '740 k DZD', sub: 'Budget 800k', color: 'text-amber-600' },
          { label: 'MARGE BRUTE', value: '38,2%', sub: 'Objectif 40%', color: 'text-green-700' },
          { label: 'CA CUMULÉ 2025', value: '5,65 M DZD', sub: 'Objectif 15,2M', color: 'text-green-700' },
          { label: 'TRI PRÉVISIONNEL', value: '15%', sub: 'Horizon 7 ans', color: 'text-green-700' },
        ].map((k, i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-label">{k.label}</div>
            <div className={`text-lg font-medium ${k.color}`}>{k.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        {/* CA vs OPEX */}
        <div className="card">
          <div className="font-medium text-sm mb-4">CA vs OPEX mensuel (k DZD)</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={caData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Bar dataKey="ca" name="CA" fill="#9FE1CB" radius={[3,3,0,0]} />
              <Bar dataKey="opex" name="OPEX" fill="#FAC775" radius={[3,3,0,0]} />
              <Line type="monotone" dataKey="marge" stroke="#0F6E56" strokeWidth={2} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Projections 5 ans */}
        <div className="card">
          <div className="font-medium text-sm mb-4">Projections CA — Plan 5 ans (M DZD)</div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={projections}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="annee" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Line type="monotone" dataKey="ca" name="CA (M DZD)" stroke="#1D9E75" strokeWidth={2.5} dot={{ fill: '#1D9E75', r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Répartition revenus */}
      <div className="card mb-6">
        <div className="font-medium text-sm mb-4">Répartition des revenus — Jan 2025</div>
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: 'Viande ovine', value: '1 358 000 DZD', pct: 75, color: '#1D9E75' },
            { label: 'Reproducteurs certifiés', value: '130 000 DZD', pct: 8, color: '#0F6E56' },
            { label: 'Fourrage excédentaire', value: '71 400 DZD', pct: 5, color: '#BA7517' },
            { label: 'Sous-produits (laine, fumier)', value: '54 000 DZD', pct: 3, color: '#888780' },
          ].map((r, i) => (
            <div key={i} className="kpi-card">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: r.color }}></div>
                <span className="text-xs text-gray-500">{r.label}</span>
              </div>
              <div className="text-sm font-medium" style={{ color: r.color }}>{r.value}</div>
              <div className="mt-2 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${r.pct * 1.33}%`, backgroundColor: r.color }}></div>
              </div>
              <div className="text-xs text-gray-400 mt-1">{r.pct}% du CA</div>
            </div>
          ))}
        </div>
      </div>

      {/* Dernières ventes */}
      <div className="card overflow-hidden p-0">
        <div className="p-4 border-b border-gray-100">
          <div className="font-medium text-sm">Dernières ventes</div>
        </div>
        <table className="data-table">
          <thead>
            <tr className="bg-gray-50">
              <th>Date</th>
              <th>Produit</th>
              <th>Quantité</th>
              <th>Prix unitaire</th>
              <th>Total DZD</th>
              <th>Acheteur</th>
            </tr>
          </thead>
          <tbody>
            {ventes.map((v, i) => (
              <tr key={i}>
                <td className="text-xs text-gray-500">{v.date}</td>
                <td className="text-sm font-medium">{v.produit}</td>
                <td className="text-xs">{v.qte}</td>
                <td className="text-xs text-gray-500">{v.prix}</td>
                <td className="text-sm font-medium text-green-700">{v.total}</td>
                <td className="text-xs text-gray-500">{v.acheteur}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
