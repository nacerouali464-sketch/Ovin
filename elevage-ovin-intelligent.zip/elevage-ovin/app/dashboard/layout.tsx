'use client'
// app/dashboard/layout.tsx — Shell principal du back-office

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const navItems = [
  { href: '/dashboard', icon: '📊', label: 'Vue exécutive' },
  { href: '/dashboard/cheptel', icon: '🐑', label: 'Cheptel' },
  { href: '/dashboard/reproduction', icon: '🧬', label: 'Reproduction' },
  { href: '/dashboard/sante', icon: '💉', label: 'Santé' },
  { href: '/dashboard/nutrition', icon: '🌿', label: 'Nutrition' },
  { href: '/dashboard/hydroponie', icon: '💧', label: 'Hydroponie' },
  { href: '/dashboard/iot', icon: '📡', label: 'IoT Capteurs' },
  { href: '/dashboard/energie', icon: '☀️', label: 'Énergie solaire' },
  { href: '/dashboard/finance', icon: '💰', label: 'Finance' },
  { href: '/dashboard/tracabilite', icon: '🔏', label: 'Traçabilité' },
  { href: '/dashboard/esg', icon: '🌱', label: 'ESG' },
  { href: '/dashboard/alertes', icon: '🔔', label: 'Alertes', badge: 3 },
  { href: '/dashboard/admin', icon: '⚙️', label: 'Administration' },
]

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(true)

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-56' : 'w-14'} bg-white border-r border-gray-100 flex flex-col transition-all duration-200 flex-shrink-0`}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-gray-100">
          <div className="w-8 h-8 bg-green-700 rounded-lg flex items-center justify-center flex-shrink-0">
            <span className="text-base">🐑</span>
          </div>
          {sidebarOpen && (
            <div className="overflow-hidden">
              <div className="text-xs font-medium truncate">Élevage Ovin</div>
              <div className="text-xs text-gray-400 truncate">Sidi Bel Abbès</div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          {navItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`sidebar-link mb-1 ${isActive ? 'active' : ''}`}
              >
                <span className="text-base flex-shrink-0">{item.icon}</span>
                {sidebarOpen && (
                  <span className="flex-1 truncate">{item.label}</span>
                )}
                {sidebarOpen && item.badge && (
                  <span className="bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </Link>
            )
          })}
        </nav>

        {/* Footer sidebar */}
        <div className="p-3 border-t border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-green-100 rounded-full flex items-center justify-center text-xs font-medium text-green-700 flex-shrink-0">
              DG
            </div>
            {sidebarOpen && (
              <div className="overflow-hidden">
                <div className="text-xs font-medium truncate">Directeur Général</div>
                <div className="text-xs text-gray-400 truncate">Admin</div>
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <header className="bg-white border-b border-gray-100 px-6 py-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-gray-400 hover:text-gray-600"
            >
              ☰
            </button>
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <span className="w-2 h-2 bg-green-500 rounded-full pulse-dot"></span>
              Données en direct
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs text-gray-400">Lun 20 Jan 2025 · 09:42</span>
            <div className="relative">
              <span className="text-xl cursor-pointer">🔔</span>
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">3</span>
            </div>
            <Link href="/" className="text-xs text-gray-400 hover:text-green-700 border border-gray-200 px-3 py-1 rounded-lg">
              ← Vitrine
            </Link>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  )
}
