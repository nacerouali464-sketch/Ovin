'use client'
// app/dashboard/reproduction/page.tsx

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

const gestationsEnCours = [
  { id: 'EOI-0002', race: 'Ouled Djellal', datesSaillie: '2024-11-10', naissancePrevu: '2025-04-08', semaine: 10, statut: 'gestation_confirmee' },
  { id: 'EOI-0005', race: 'Rembi', datesSaillie: '2024-11-15', naissancePrevu: '2025-04-13', semaine: 9, statut: 'gestation_confirmee' },
  { id: 'EOI-0010', race: 'Ouled Djellal', datesSaillie: '2024-11-20', naissancePrevu: '2025-04-18', semaine: 8, statut: 'gestation_confirmee' },
  { id: 'EOI-0100', race: 'Hamra', datesSaillie: '2024-11-22', naissancePrevu: '2025-04-20', semaine: 8, statut: 'gestation_confirmee' },
  { id: 'EOI-0450', race: 'Ouled Djellal', datesSaillie: '2024-12-01', naissancePrevu: '2025-04-29', semaine: 7, statut: 'gestation_avancee' },
]

const statsRepro = [
  { mois: 'Sep', agnelages: 18, saillies: 42, fertilite: 86 },
  { mois: 'Oct', agnelages: 22, saillies: 48, fertilite: 88 },
  { mois: 'Nov', agnelages: 28, saillies: 55, fertilite: 85 },
  { mois: 'Déc', agnelages: 35, saillies: 60, fertilite: 87 },
  { mois: 'Jan', agnelages: 31, saillies: 55, fertilite: 87 },
]

export default function ReproductionPage() {
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Reproduction</h1>
          <p className="text-sm text-gray-500 mt-0.5">Suivi des chaleurs, saillies, gestations et agnelages</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-outline text-sm">📅 Calendrier</button>
          <button className="btn-primary text-sm">+ Enregistrer saillie</button>
        </div>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-5 gap-4 mb-6">
        {[
          { label: 'EN GESTATION', value: '48', sub: 'Confirmées écho', color: 'text-blue-600' },
          { label: 'AGNELAGES (MOIS)', value: '31', sub: '28 agneaux vivants', color: 'text-green-700' },
          { label: 'SAILLIES (MOIS)', value: '55', sub: 'Taux prise 87%', color: 'text-green-700' },
          { label: 'FERTILITÉ GLOBALE', value: '87,4%', sub: '↑ +3.2%', color: 'text-green-700' },
          { label: 'MORTALITÉ NÉONATALE', value: '2,1%', sub: 'Objectif < 3%', color: 'text-green-700' },
        ].map((k, i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-label">{k.label}</div>
            <div className={`text-xl font-medium ${k.color}`}>{k.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-6 mb-6">
        {/* Graphique */}
        <div className="card">
          <div className="font-medium text-sm mb-4">Activité reproduction — 5 derniers mois</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={statsRepro}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Bar dataKey="agnelages" name="Agnelages" fill="#9FE1CB" radius={[3,3,0,0]} />
              <Bar dataKey="saillies" name="Saillies" fill="#FAC775" radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Agnelages prévus */}
        <div className="card">
          <div className="font-medium text-sm mb-4">Agnelages prévus — Prochains 30 jours</div>
          <div className="space-y-3">
            {[
              { date: 'Ce soir', lot: 'G1', brebis: 6, bergerie: 'B-01', alerte: true },
              { date: '22 Jan', lot: 'G2', brebis: 8, bergerie: 'B-02', alerte: false },
              { date: '25 Jan', lot: 'G3', brebis: 5, bergerie: 'B-03', alerte: false },
              { date: '28 Jan', lot: 'G1b', brebis: 11, bergerie: 'B-01', alerte: false },
              { date: '02 Fév', lot: 'G4', brebis: 9, bergerie: 'B-04', alerte: false },
            ].map((a, i) => (
              <div key={i} className={`flex items-center justify-between py-2 px-3 rounded-lg ${a.alerte ? 'bg-green-50 border border-green-200' : 'bg-gray-50'}`}>
                <div>
                  <span className={`text-sm font-medium ${a.alerte ? 'text-green-700' : ''}`}>{a.date}</span>
                  <span className="text-xs text-gray-400 ml-2">Lot {a.lot}</span>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">{a.brebis} brebis</div>
                  <div className="text-xs text-gray-400">{a.bergerie}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Gestations en cours */}
      <div className="card overflow-hidden p-0">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <div className="font-medium text-sm">Gestations en cours — Top 5 (sur 48)</div>
          <button className="text-xs text-green-700 hover:underline">Voir toutes →</button>
        </div>
        <table className="data-table">
          <thead>
            <tr className="bg-gray-50">
              <th>Identifiant</th>
              <th>Race</th>
              <th>Date saillie</th>
              <th>Naissance prévue</th>
              <th>Avancement</th>
              <th>Statut</th>
            </tr>
          </thead>
          <tbody>
            {gestationsEnCours.map((g) => (
              <tr key={g.id}>
                <td className="font-medium text-green-700 text-xs">{g.id}</td>
                <td className="text-xs">{g.race}</td>
                <td className="text-xs text-gray-500">{g.datesSaillie}</td>
                <td className="text-xs font-medium">{g.naissancePrevu}</td>
                <td>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-blue-400 rounded-full" style={{ width: `${(g.semaine / 21) * 100}%` }}></div>
                    </div>
                    <span className="text-xs text-gray-400">S{g.semaine}/21</span>
                  </div>
                </td>
                <td><span className="badge-green text-xs">Confirmée</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
