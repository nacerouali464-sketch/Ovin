'use client'
// app/dashboard/sante/page.tsx

import { useState } from 'react'

const protocoles = [
  { id: 'P-001', nom: 'Vaccin Pasteurellose', lot: 'B-02', animaux: 38, date: '2025-01-17', statut: 'en_retard', couleur: 'badge-red' },
  { id: 'P-002', nom: 'Vaccin Entérotoxémie', lot: 'B-01', animaux: 95, date: '2025-02-01', statut: 'planifié', couleur: 'badge-green' },
  { id: 'P-003', nom: 'Déparasitage hivernal', lot: 'Tout cheptel', animaux: 512, date: '2025-02-15', statut: 'planifié', couleur: 'badge-green' },
  { id: 'P-004', nom: 'Vaccin Brucellose', lot: 'B-03, B-04', animaux: 142, date: '2025-03-01', statut: 'planifié', couleur: 'badge-green' },
]

const historique = [
  { date: '2025-01-20', animal: 'EOI-0247', type: 'Diagnostic', detail: 'Suspicion pneumonie', vet: 'Dr. Benamara', cout: '—', resolu: false },
  { date: '2025-01-18', animal: 'EOI-0189', type: 'Traitement', detail: 'Fourbure pied droit — Sulfate de cuivre', vet: 'Dr. Benamara', cout: '850 DZD', resolu: false },
  { date: '2025-01-15', animal: 'Lot B-01', type: 'Vaccination', detail: 'Rappel Clavelée — 95 têtes', vet: 'Dr. Benamara', cout: '14 250 DZD', resolu: true },
  { date: '2025-01-10', animal: 'EOI-0312', type: 'Visite vétérinaire', detail: 'Contrôle croissance agneau', vet: 'Dr. Benamara', cout: '2 000 DZD', resolu: true },
  { date: '2025-01-05', animal: 'Lot B-02', type: 'Déparasitage', detail: 'Ivermectine 0.2 mg/kg — 87 têtes', vet: 'Responsable élevage', cout: '9 600 DZD', resolu: true },
]

export default function SantePage() {
  const [onglet, setOnglet] = useState<'protocoles' | 'historique' | 'alertes'>('protocoles')

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Santé & Vétérinaire</h1>
          <p className="text-sm text-gray-500 mt-0.5">Suivi sanitaire du cheptel — Dr. Benamara (vétérinaire référent)</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-outline text-sm">📋 Protocole sanitaire</button>
          <button className="btn-primary text-sm">+ Nouvelle intervention</button>
        </div>
      </div>

      {/* KPI Santé */}
      <div className="grid grid-cols-5 gap-4 mb-6">
        {[
          { label: 'ANIMAUX MALADES', value: '9', sub: '1,8% du cheptel', color: 'text-red-600' },
          { label: 'EN QUARANTAINE', value: '3', sub: 'Box isolement', color: 'text-amber-600' },
          { label: 'TRAITEMENTS EN COURS', value: '6', sub: '3 critiques', color: 'text-amber-600' },
          { label: 'VACCINATIONS À FAIRE', value: '1', sub: 'En retard — B-02', color: 'text-red-600' },
          { label: 'COÛT SANTÉ (MOIS)', value: '26 700 DZD', sub: 'Budget 35 000', color: 'text-green-700' },
        ].map((k, i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-label">{k.label}</div>
            <div className={`text-lg font-medium ${k.color}`}>{k.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{k.sub}</div>
          </div>
        ))}
      </div>

      {/* Onglets */}
      <div className="flex gap-1 mb-4 border-b border-gray-100">
        {[
          { key: 'protocoles', label: 'Protocoles & Vaccinations' },
          { key: 'historique', label: 'Historique interventions' },
          { key: 'alertes', label: 'Alertes sanitaires' },
        ].map(o => (
          <button
            key={o.key}
            onClick={() => setOnglet(o.key as any)}
            className={`px-4 py-2 text-sm border-b-2 transition-colors ${onglet === o.key ? 'border-green-600 text-green-700 font-medium' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
          >
            {o.label}
          </button>
        ))}
      </div>

      {onglet === 'protocoles' && (
        <div className="card overflow-hidden p-0">
          <table className="data-table">
            <thead>
              <tr className="bg-gray-50">
                <th>Protocole</th>
                <th>Lot / Groupe</th>
                <th>Animaux</th>
                <th>Date prévue</th>
                <th>Statut</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {protocoles.map((p) => (
                <tr key={p.id}>
                  <td className="font-medium text-sm">{p.nom}</td>
                  <td className="text-xs">{p.lot}</td>
                  <td className="text-sm">{p.animaux} têtes</td>
                  <td className="text-xs text-gray-500">{p.date}</td>
                  <td>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${p.couleur}`}>
                      {p.statut === 'en_retard' ? '⚠ En retard' : '✓ Planifié'}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button className="text-xs text-green-700 hover:underline">Valider</button>
                      <button className="text-xs text-gray-400 hover:underline">Reporter</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {onglet === 'historique' && (
        <div className="card overflow-hidden p-0">
          <table className="data-table">
            <thead>
              <tr className="bg-gray-50">
                <th>Date</th>
                <th>Animal / Lot</th>
                <th>Type</th>
                <th>Détail</th>
                <th>Vétérinaire</th>
                <th>Coût</th>
                <th>Résolu</th>
              </tr>
            </thead>
            <tbody>
              {historique.map((h, i) => (
                <tr key={i}>
                  <td className="text-xs text-gray-500">{h.date}</td>
                  <td className="font-medium text-xs text-green-700">{h.animal}</td>
                  <td><span className="badge-green text-xs">{h.type}</span></td>
                  <td className="text-xs">{h.detail}</td>
                  <td className="text-xs text-gray-500">{h.vet}</td>
                  <td className="text-xs font-medium">{h.cout}</td>
                  <td>
                    <span className={`text-xs ${h.resolu ? 'text-green-600' : 'text-red-500'}`}>
                      {h.resolu ? '✓ Résolu' : '⏳ En cours'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {onglet === 'alertes' && (
        <div className="space-y-3">
          {[
            { severity: 'critique', animal: 'EOI-0247', message: 'Score IA 82/100 — Suspicion pneumonie. Isolement immédiat requis.', temps: 'il y a 14 min' },
            { severity: 'critique', animal: 'EOI-0189', message: 'Score IA 71/100 — Fourbure non résolue, risque aggravation.', temps: 'il y a 2 jours' },
            { severity: 'modere', animal: 'Lot B-02', message: 'Vaccination Pasteurellose en retard de 3 jours. Contacter vétérinaire.', temps: 'il y a 3 jours' },
            { severity: 'info', animal: 'EOI-0312', message: 'Agneau 3 mois — Poids 22.4 kg, légèrement sous la courbe de croissance.', temps: 'il y a 1 semaine' },
          ].map((a, i) => (
            <div key={i} className={`card border-l-4 ${a.severity === 'critique' ? 'border-l-red-500' : a.severity === 'modere' ? 'border-l-amber-500' : 'border-l-green-500'}`}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${a.severity === 'critique' ? 'badge-red' : a.severity === 'modere' ? 'badge-amber' : 'badge-green'}`}>
                      {a.severity.toUpperCase()}
                    </span>
                    <span className="text-xs font-medium text-green-700">{a.animal}</span>
                  </div>
                  <p className="text-sm">{a.message}</p>
                  <p className="text-xs text-gray-400 mt-1">{a.temps}</p>
                </div>
                <button className="btn-outline text-xs ml-4">Traiter</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
