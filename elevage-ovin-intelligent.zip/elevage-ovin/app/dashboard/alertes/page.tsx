'use client'
// app/dashboard/alertes/page.tsx

import { useState } from 'react'

const toutesAlertes = [
  { id: 1, severity: 'critique', module: 'IA Santé', titre: 'Brebis EOI-0247 — Score risque 82/100', message: 'Analyse biométrique : fréquence respiratoire 28/min, température 40.2°C, activité -65% sur 6h. Isolement recommandé sous 2h.', temps: 'il y a 14 min', resolu: false },
  { id: 2, severity: 'critique', module: 'IoT', titre: 'Température Bergerie B — 38.9°C', message: 'Capteur T-BB-01 : dépassement seuil max (30°C) depuis 32 minutes. Vérifier ventilation. 87 animaux exposés.', temps: 'il y a 32 min', resolu: false },
  { id: 3, severity: 'modere', module: 'Hydroponie', titre: 'Stock fourrage critique — 2.8 jours', message: 'Niveau sous le seuil de sécurité (3 jours). Lancer cycle C-12 immédiatement.', temps: 'il y a 1h', resolu: false },
  { id: 4, severity: 'modere', module: 'Santé', titre: 'Vaccination Pasteurellose en retard — Lot B-02', message: 'Rappel vaccin en retard de 3 jours pour 38 animaux. Contacter Dr. Benamara.', temps: 'il y a 3 jours', resolu: false },
  { id: 5, severity: 'info', module: 'Reproduction', titre: '6 agnelages attendus ce soir', message: 'Lot G1 — 6 brebis en fin de gestation. Présence recommandée à partir de 20h00.', temps: 'Prévision J', resolu: false },
  { id: 6, severity: 'info', module: 'Énergie', titre: 'Production solaire optimale prévue demain', message: 'Ensoleillement 9h prévu. Production estimée 340-360 kWh. Planifier travaux énergivores.', temps: 'il y a 2h', resolu: false },
  { id: 7, severity: 'modere', module: 'IA Santé', titre: 'Brebis EOI-0189 — Score risque 71/100', message: 'Fourbure non résolue depuis 2 jours. Risque d\'aggravation. Suivi vétérinaire recommandé.', temps: 'il y a 2 jours', resolu: false },
]

const colorMap: Record<string, string> = {
  critique: 'border-l-red-500',
  modere: 'border-l-amber-400',
  info: 'border-l-green-400',
}

const badgeMap: Record<string, string> = {
  critique: 'badge-red',
  modere: 'badge-amber',
  info: 'badge-green',
}

export default function AlertesPage() {
  const [filtre, setFiltre] = useState('tous')

  const filtered = toutesAlertes.filter(a => filtre === 'tous' || a.severity === filtre)

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Alertes & Notifications</h1>
          <p className="text-sm text-gray-500 mt-0.5">7 alertes actives · 2 critiques non résolues</p>
        </div>
        <button className="btn-outline text-sm">✓ Tout marquer résolu</button>
      </div>

      <div className="flex gap-2 mb-6">
        {[
          { key: 'tous', label: 'Toutes (7)' },
          { key: 'critique', label: '🔴 Critiques (2)' },
          { key: 'modere', label: '🟡 Modérées (3)' },
          { key: 'info', label: '🟢 Info (2)' },
        ].map(f => (
          <button
            key={f.key}
            onClick={() => setFiltre(f.key)}
            className={`text-xs px-4 py-2 rounded-lg border transition-colors ${filtre === f.key ? 'bg-green-700 text-white border-green-700' : 'border-gray-200 text-gray-500 hover:bg-gray-50'}`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filtered.map((a) => (
          <div key={a.id} className={`card border-l-4 ${colorMap[a.severity]}`}>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${badgeMap[a.severity]}`}>
                    {a.severity.toUpperCase()}
                  </span>
                  <span className="text-xs text-gray-400 font-medium">{a.module}</span>
                  <span className="text-xs text-gray-300">·</span>
                  <span className="text-xs text-gray-400">{a.temps}</span>
                </div>
                <div className="font-medium text-sm mb-1">{a.titre}</div>
                <p className="text-xs text-gray-500 leading-relaxed">{a.message}</p>
              </div>
              <div className="flex gap-2 ml-4 flex-shrink-0">
                <button className="btn-primary text-xs py-1.5 px-3">Traiter</button>
                <button className="btn-outline text-xs py-1.5 px-3">Ignorer</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
