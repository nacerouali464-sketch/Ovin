'use client'
// app/dashboard/nutrition/page.tsx

export default function NutritionPage() {
  const profils = [
    { nom: 'Brebis gestante 1er tiers', animaux: 28, ration: 1.8, cout: 51.3, ingredients: ['Foin: 1.0 kg', 'Orge: 0.5 kg', 'Hydroponique: 0.2 kg', 'CMV: 0.1 kg'] },
    { nom: 'Brebis gestante dernier tiers', animaux: 20, ration: 2.1, cout: 65.1, ingredients: ['Foin: 1.1 kg', 'Orge: 0.6 kg', 'Hydroponique: 0.3 kg', 'CMV: 0.1 kg'] },
    { nom: 'Brebis allaitante', animaux: 31, ration: 2.4, cout: 76.8, ingredients: ['Foin: 1.2 kg', 'Orge: 0.7 kg', 'Hydroponique: 0.4 kg', 'CMV: 0.1 kg'] },
    { nom: 'Agneau engraissement', animaux: 78, ration: 1.2, cout: 42.0, ingredients: ['Foin: 0.5 kg', 'Orge: 0.4 kg', 'Hydroponique: 0.3 kg'] },
    { nom: 'Bélier reproducteur', animaux: 24, ration: 2.0, cout: 52.0, ingredients: ['Foin: 1.4 kg', 'Orge: 0.4 kg', 'Hydroponique: 0.2 kg'] },
    { nom: 'Brebis entretien', animaux: 331, ration: 1.5, cout: 33.0, ingredients: ['Foin: 1.2 kg', 'Orge: 0.2 kg', 'Hydroponique: 0.1 kg'] },
  ]

  const coutTotal = profils.reduce((acc, p) => acc + (p.animaux * p.cout), 0)

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Nutrition & Rations</h1>
          <p className="text-sm text-gray-500 mt-0.5">6 profils nutritionnels · Optimisation IA active</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-outline text-sm">🤖 Optimiser rations IA</button>
          <button className="btn-primary text-sm">+ Nouveau profil</button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { label: 'COÛT RATION / JOUR', value: `${Math.round(coutTotal).toLocaleString()} DZD`, sub: '512 animaux', color: 'text-green-700' },
          { label: 'COÛT / MOIS', value: `${Math.round(coutTotal * 30 / 1000).toLocaleString()} k DZD`, sub: 'Budget 800k', color: 'text-green-700' },
          { label: 'ÉCONOMIE IA', value: '-18%', sub: 'vs rations standard', color: 'text-green-700' },
          { label: 'FOURRAGE HYDROPONIQUE', value: '32%', sub: 'de la ration totale', color: 'text-amber-600' },
        ].map((k, i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-label">{k.label}</div>
            <div className={`text-xl font-medium ${k.color}`}>{k.value}</div>
            <div className="text-xs text-gray-400 mt-0.5">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4">
        {profils.map((p, i) => (
          <div key={i} className="card">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <div className="font-medium text-sm">{p.nom}</div>
                  <span className="badge-green">{p.animaux} animaux</span>
                </div>
                <div className="flex gap-6 text-xs text-gray-500">
                  <span>Ration : <strong className="text-gray-700">{p.ration} kg/jour</strong></span>
                  <span>Coût : <strong className="text-green-700">{p.cout} DZD/animal/jour</strong></span>
                  <span>Total jour : <strong className="text-green-700">{Math.round(p.animaux * p.cout).toLocaleString()} DZD</strong></span>
                </div>
                <div className="flex gap-2 mt-2 flex-wrap">
                  {p.ingredients.map((ing, j) => (
                    <span key={j} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{ing}</span>
                  ))}
                </div>
              </div>
              <button className="btn-outline text-xs ml-4">Modifier</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
