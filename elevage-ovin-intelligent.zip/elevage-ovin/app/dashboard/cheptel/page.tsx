'use client'
// app/dashboard/cheptel/page.tsx

import { useState } from 'react'

const animaux = [
  { id:'EOI-0001', race:'Ouled Djellal', sexe:'F', age:'3 ans 10m', bergerie:'B-01', statut:'actif', poids:62.5, score:8 },
  { id:'EOI-0002', race:'Ouled Djellal', sexe:'F', age:'4 ans 5m', bergerie:'B-01', statut:'gestante', poids:68.0, score:12 },
  { id:'EOI-0003', race:'Hamra', sexe:'F', age:'2 ans 11m', bergerie:'B-02', statut:'allaitante', poids:55.3, score:18 },
  { id:'EOI-0004', race:'Ouled Djellal', sexe:'M', age:'5 ans 2m', bergerie:'B-02', statut:'actif', poids:95.0, score:5 },
  { id:'EOI-0005', race:'Rembi', sexe:'F', age:'3 ans 6m', bergerie:'B-03', statut:'gestante', poids:58.7, score:22 },
  { id:'EOI-0098', race:'Ouled Djellal', sexe:'M', age:'3 ans', bergerie:'B-02', statut:'actif', poids:88.0, score:44 },
  { id:'EOI-0189', race:'Hamra', sexe:'F', age:'6 ans 7m', bergerie:'B-01', statut:'malade', poids:52.1, score:71 },
  { id:'EOI-0247', race:'Ouled Djellal', sexe:'F', age:'5 ans 5m', bergerie:'B-03', statut:'malade', poids:48.2, score:82 },
  { id:'EOI-0312', race:'Rembi', sexe:'M', age:'3 mois', bergerie:'B-05', statut:'actif', poids:22.4, score:58 },
  { id:'EOI-0401', race:'Hamra', sexe:'F', age:'2 ans', bergerie:'B-04', statut:'actif', poids:57.8, score:22 },
]

const statutColors: Record<string, string> = {
  actif: 'badge-green',
  gestante: 'bg-blue-50 text-blue-700',
  allaitante: 'bg-purple-50 text-purple-700',
  malade: 'badge-red',
  quarantaine: 'badge-amber',
}

export default function CheptelPage() {
  const [search, setSearch] = useState('')
  const [filtre, setFiltre] = useState('tous')

  const filtered = animaux.filter(a =>
    (filtre === 'tous' || a.statut === filtre) &&
    (a.id.toLowerCase().includes(search.toLowerCase()) || a.race.toLowerCase().includes(search.toLowerCase()))
  )

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Gestion du cheptel</h1>
          <p className="text-sm text-gray-500 mt-0.5">512 animaux · Dernière mise à jour il y a 4 min</p>
        </div>
        <div className="flex gap-3">
          <button className="btn-outline text-sm">📥 Importer CSV</button>
          <button className="btn-outline text-sm">📄 Exporter PDF</button>
          <button className="btn-primary text-sm">+ Nouvel animal</button>
        </div>
      </div>

      {/* Stats rapides */}
      <div className="grid grid-cols-5 gap-4 mb-6">
        {[
          { label: 'Brebis actives', value: '382', color: 'text-green-700' },
          { label: 'En gestation', value: '48', color: 'text-blue-600' },
          { label: 'Allaitantes', value: '31', color: 'text-purple-600' },
          { label: 'Malades', value: '9', color: 'text-red-600' },
          { label: 'Score moyen IA', value: '18/100', color: 'text-amber-600' },
        ].map((s, i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-label">{s.label}</div>
            <div className={`text-xl font-medium ${s.color}`}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Filtres */}
      <div className="flex gap-3 mb-4">
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Rechercher par ID ou race..."
          className="border border-gray-200 rounded-lg px-3 py-2 text-sm flex-1 focus:outline-none focus:border-green-500"
        />
        <select
          value={filtre}
          onChange={e => setFiltre(e.target.value)}
          className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none"
        >
          <option value="tous">Tous les statuts</option>
          <option value="actif">Actif</option>
          <option value="gestante">Gestante</option>
          <option value="allaitante">Allaitante</option>
          <option value="malade">Malade</option>
        </select>
      </div>

      {/* Table */}
      <div className="card overflow-hidden p-0">
        <table className="data-table">
          <thead>
            <tr className="bg-gray-50">
              <th>Identifiant</th>
              <th>Race</th>
              <th>Sexe</th>
              <th>Âge</th>
              <th>Bergerie</th>
              <th>Statut</th>
              <th>Poids (kg)</th>
              <th>Score IA</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((a) => (
              <tr key={a.id} className="hover:bg-gray-50 cursor-pointer">
                <td className="font-medium text-green-700">{a.id}</td>
                <td>{a.race}</td>
                <td>{a.sexe === 'F' ? '♀ Femelle' : '♂ Mâle'}</td>
                <td>{a.age}</td>
                <td><span className="badge-green">{a.bergerie}</span></td>
                <td>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statutColors[a.statut] || 'bg-gray-100 text-gray-600'}`}>
                    {a.statut.charAt(0).toUpperCase() + a.statut.slice(1)}
                  </span>
                </td>
                <td>{a.poids} kg</td>
                <td>
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${a.score}%`,
                          backgroundColor: a.score >= 70 ? '#E24B4A' : a.score >= 40 ? '#BA7517' : '#1D9E75'
                        }}
                      ></div>
                    </div>
                    <span className="text-xs font-medium" style={{
                      color: a.score >= 70 ? '#E24B4A' : a.score >= 40 ? '#BA7517' : '#1D9E75'
                    }}>{a.score}</span>
                  </div>
                </td>
                <td>
                  <div className="flex gap-2">
                    <button className="text-xs text-green-700 hover:underline">Fiche</button>
                    <button className="text-xs text-gray-400 hover:underline">Santé</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="px-4 py-3 text-xs text-gray-400 border-t border-gray-100">
          Affichage de {filtered.length} animaux sur 512
        </div>
      </div>
    </div>
  )
}
