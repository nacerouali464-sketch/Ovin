'use client'
// app/dashboard/page.tsx — Vue exécutive avec KPI temps réel

import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

// Données simulées réalistes
const cheptelData = [
  { mois: 'Jan', tetes: 500, ca: 980 },
  { mois: 'Fév', tetes: 502, ca: 1020 },
  { mois: 'Mar', tetes: 504, ca: 1050 },
  { mois: 'Avr', tetes: 506, ca: 1080 },
  { mois: 'Mai', tetes: 507, ca: 1120 },
  { mois: 'Jun', tetes: 508, ca: 1180 },
  { mois: 'Jul', tetes: 509, ca: 1200 },
  { mois: 'Aoû', tetes: 510, ca: 1250 },
  { mois: 'Sep', tetes: 510, ca: 1320 },
  { mois: 'Oct', tetes: 511, ca: 1380 },
  { mois: 'Nov', tetes: 512, ca: 1410 },
  { mois: 'Déc', tetes: 512, ca: 1420 },
]

const reproData = [
  { mois: 'Jan', agnelages: 31, saillies: 55 },
  { mois: 'Fév', agnelages: 28, saillies: 60 },
  { mois: 'Mar', agnelages: 35, saillies: 48 },
  { mois: 'Avr', agnelages: 22, saillies: 52 },
  { mois: 'Mai', agnelages: 18, saillies: 45 },
  { mois: 'Jun', agnelages: 0, saillies: 0 },
]

const racesData = [
  { name: 'Ouled Djellal', value: 65, color: '#1D9E75' },
  { name: 'Hamra', value: 22, color: '#BA7517' },
  { name: 'Rembi', value: 13, color: '#378ADD' },
]

const alertes = [
  { severity: 'critique', color: '#E24B4A', title: 'Brebis EOI-0247 — Score risque 82/100', time: 'il y a 14 min', module: 'IA Santé' },
  { severity: 'critique', color: '#E24B4A', title: 'Capteur T° Bergerie B — 38.9°C', time: 'il y a 32 min', module: 'IoT' },
  { severity: 'modere', color: '#BA7517', title: 'Stock fourrage hydroponique < 3 jours', time: 'il y a 1h', module: 'Hydroponie' },
  { severity: 'info', color: '#1D9E75', title: '6 agnelages attendus ce soir (lots G1)', time: 'Prévision J', module: 'Reproduction' },
]

const animauxRisque = [
  { id: 'EOI-0247', info: 'Brebis · 4 ans · B-03', score: 82, niveau: 'Critique', color: '#E24B4A' },
  { id: 'EOI-0189', info: 'Brebis · 6 ans · B-01', score: 71, niveau: 'Élevé', color: '#E24B4A' },
  { id: 'EOI-0312', info: 'Agneau · 3 mois · B-05', score: 58, niveau: 'Modéré', color: '#BA7517' },
  { id: 'EOI-0098', info: 'Bélier · 3 ans · B-02', score: 44, niveau: 'Modéré', color: '#BA7517' },
  { id: 'EOI-0401', info: 'Brebis · 2 ans · B-04', score: 22, niveau: 'Faible', color: '#1D9E75' },
]

const capteurs = [
  { label: 'Bergerie A', value: '23.4°C', status: 'Normal', ok: true },
  { label: 'Bergerie B', value: '38.9°C', status: 'Alerte', ok: false },
  { label: 'Humidité moy.', value: '65%', status: 'Normal', ok: true },
  { label: 'Eau / jour', value: '8 200 L', status: 'Normal', ok: true },
  { label: 'Activité', value: '+12%', status: 'Vigilance', ok: null },
  { label: 'Capteurs actifs', value: '118/120', status: '98.3%', ok: true },
]

export default function DashboardPage() {
  return (
    <div className="p-6 space-y-6">

      {/* KPI principaux */}
      <div className="grid grid-cols-6 gap-4">
        {[
          { label: 'CHEPTEL TOTAL', value: '512', sub: '↑ +12 ce mois', subColor: 'text-green-600' },
          { label: 'TAUX FERTILITÉ', value: '87,4%', sub: '↑ +3,2% vs mois', subColor: 'text-green-600' },
          { label: 'TAUX MORTALITÉ', value: '1,8%', sub: '↓ Objectif 2%', subColor: 'text-green-600' },
          { label: 'CA MENSUEL (DZD)', value: '1,42 M', sub: '↑ +8% vs jan', subColor: 'text-green-600' },
          { label: 'MARGE BRUTE', value: '38,2%', sub: 'Objectif 40%', subColor: 'text-gray-400' },
          { label: 'ALERTES ACTIVES', value: '3', sub: '2 critiques', subColor: 'text-red-500' },
        ].map((kpi, i) => (
          <div key={i} className="kpi-card">
            <div className="kpi-label">{kpi.label}</div>
            <div className="kpi-value">{kpi.value}</div>
            <div className={`text-xs mt-1 ${kpi.subColor}`}>{kpi.sub}</div>
          </div>
        ))}
      </div>

      {/* Ligne 2 : Graphique cheptel + Alertes */}
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2 card">
          <div className="flex items-center justify-between mb-4">
            <div className="font-medium text-sm">Évolution cheptel & CA mensuel</div>
            <span className="text-xs text-gray-400">Jan – Déc 2025</span>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={cheptelData} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip />
              <Bar dataKey="ca" name="CA (k DZD)" fill="#FAC775" radius={[3, 3, 0, 0]} />
              <Line type="monotone" dataKey="tetes" stroke="#1D9E75" strokeWidth={2} dot={false} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="font-medium text-sm mb-4">Alertes critiques <span className="text-xs text-gray-400 font-normal">Temps réel</span></div>
          <div className="space-y-3">
            {alertes.map((a, i) => (
              <div key={i} className="flex gap-3">
                <div className="w-2 h-2 rounded-full mt-1 flex-shrink-0" style={{ backgroundColor: a.color }}></div>
                <div>
                  <div className="text-xs font-medium" style={{ color: a.severity === 'critique' ? a.color : 'inherit' }}>{a.title}</div>
                  <div className="text-xs text-gray-400">{a.time} · {a.module}</div>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-4 text-xs border border-gray-200 rounded-lg py-2 hover:bg-gray-50 text-gray-500">
            Voir toutes les alertes →
          </button>
        </div>
      </div>

      {/* Ligne 3 : Cheptel + Reproduction + Scoring IA */}
      <div className="grid grid-cols-3 gap-4">
        {/* Composition cheptel */}
        <div className="card">
          <div className="font-medium text-sm mb-4">Composition du cheptel</div>
          <div className="space-y-3 mb-4">
            {[
              { label: 'Brebis mères', count: 382, pct: 74.6, color: '#1D9E75' },
              { label: 'Agneaux < 6 mois', count: 78, pct: 15.2, color: '#BA7517' },
              { label: 'Béliers reproducteurs', count: 24, pct: 4.7, color: '#1D9E75' },
              { label: 'Agnelles renouvellement', count: 28, pct: 5.5, color: '#BA7517' },
            ].map((c, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs mb-1">
                  <span>{c.label}</span>
                  <span className="text-gray-400">{c.count} ({c.pct}%)</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${c.pct}%`, backgroundColor: c.color }}></div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-center">
            <PieChart width={120} height={120}>
              <Pie data={racesData} cx={55} cy={55} innerRadius={30} outerRadius={55} dataKey="value">
                {racesData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
            </PieChart>
          </div>
          <div className="flex gap-3 justify-center text-xs mt-2">
            {racesData.map((r, i) => (
              <span key={i} className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-sm" style={{ backgroundColor: r.color }}></span>
                {r.name.split(' ')[0]} {r.value}%
              </span>
            ))}
          </div>
        </div>

        {/* Reproduction */}
        <div className="card">
          <div className="font-medium text-sm mb-3">Reproduction — Jan 2025</div>
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div className="kpi-card text-center"><div className="kpi-label text-center" style={{fontSize:'9px'}}>GESTATION</div><div className="text-lg font-medium text-green-700">48</div></div>
            <div className="kpi-card text-center"><div className="kpi-label text-center" style={{fontSize:'9px'}}>AGNELAGES</div><div className="text-lg font-medium text-green-700">31</div></div>
            <div className="kpi-card text-center"><div className="kpi-label text-center" style={{fontSize:'9px'}}>SAILLIES</div><div className="text-lg font-medium text-amber-600">55</div></div>
          </div>
          <ResponsiveContainer width="100%" height={130}>
            <BarChart data={reproData} margin={{ top: 0, right: 0, bottom: 0, left: -25 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 9 }} />
              <Tooltip />
              <Bar dataKey="agnelages" name="Agnelages" fill="#9FE1CB" radius={[2,2,0,0]} />
              <Bar dataKey="saillies" name="Saillies" fill="#FAC775" radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Scoring IA */}
        <div className="card">
          <div className="font-medium text-sm mb-4">Scoring IA — Animaux à risque <span className="text-xs text-gray-400 font-normal">Top 5</span></div>
          <div className="space-y-2">
            {animauxRisque.map((a, i) => (
              <div key={i} className="flex items-center gap-3 py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-xs font-medium w-16">{a.id}</span>
                <span className="text-xs text-gray-400 flex-1">{a.info}</span>
                <span className="text-xs font-medium" style={{ color: a.color }}>{a.score}</span>
                <span className="text-xs px-2 py-0.5 rounded-full" style={{
                  backgroundColor: a.color + '18',
                  color: a.color
                }}>{a.niveau}</span>
              </div>
            ))}
          </div>
          <button className="w-full mt-3 text-xs border border-gray-200 rounded-lg py-2 hover:bg-gray-50 text-gray-500">
            Voir fiches animaux →
          </button>
        </div>
      </div>

      {/* Ligne 4 : IoT + Énergie + Hydroponie */}
      <div className="grid grid-cols-3 gap-4">
        {/* IoT */}
        <div className="card">
          <div className="font-medium text-sm mb-4">IoT — Capteurs temps réel</div>
          <div className="grid grid-cols-3 gap-2">
            {capteurs.map((c, i) => (
              <div key={i} className="bg-gray-50 rounded-lg p-3 text-center">
                <div className="text-sm font-medium" style={{ color: c.ok === false ? '#E24B4A' : c.ok === null ? '#BA7517' : '#0F6E56' }}>
                  {c.value}
                </div>
                <div className="text-xs text-gray-400 mt-0.5">{c.label}</div>
                <div className="text-xs mt-1 font-medium" style={{ color: c.ok === false ? '#E24B4A' : c.ok === null ? '#BA7517' : '#1D9E75' }}>
                  {c.status}
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-4 text-xs border border-gray-200 rounded-lg py-2 hover:bg-gray-50 text-gray-500">
            Tableau IoT complet →
          </button>
        </div>

        {/* Énergie solaire */}
        <div className="card">
          <div className="font-medium text-sm mb-4">Énergie solaire — 80 kWc</div>
          <div className="space-y-3">
            {[
              { label: 'Production aujourd\'hui', value: '312 kWh', pct: 78, color: '#1D9E75' },
              { label: 'Consommation', value: '198 kWh', pct: 50, color: '#BA7517' },
              { label: 'Autonomie', value: '85%', pct: 85, color: '#1D9E75' },
            ].map((e, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs mb-1">
                  <span>{e.label}</span>
                  <span className="font-medium" style={{ color: e.color }}>{e.value}</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${e.pct}%`, backgroundColor: e.color }}></div>
                </div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            <div className="bg-gray-50 rounded-lg p-3 text-center">
              <div className="text-sm font-medium text-green-700">9 360 DZD</div>
              <div className="text-xs text-gray-400">Économies aujourd'hui</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3 text-center">
              <div className="text-sm font-medium text-green-700">218 kWh</div>
              <div className="text-xs text-gray-400">Surplus réseau</div>
            </div>
          </div>
        </div>

        {/* Hydroponie */}
        <div className="card">
          <div className="font-medium text-sm mb-4">Hydroponie — 500 m²</div>
          <div className="space-y-3">
            {[
              { label: 'Cycle en cours (J6/J8)', value: '75%', pct: 75, color: '#1D9E75', bold: false },
              { label: 'Stock fourrage restant', value: '2,8 jours', pct: 28, color: '#E24B4A', bold: true },
              { label: 'Plateaux actifs', value: '840 / 1 000', pct: 84, color: '#BA7517', bold: false },
            ].map((h, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs mb-1">
                  <span>{h.label}</span>
                  <span className={`font-medium ${h.bold ? 'text-red-500' : ''}`} style={{ color: h.bold ? undefined : h.color }}>{h.value}</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${h.pct}%`, backgroundColor: h.color }}></div>
                </div>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2 mt-4">
            <div className="bg-gray-50 rounded-lg p-3 text-center">
              <div className="text-sm font-medium text-green-700">1 680 kg</div>
              <div className="text-xs text-gray-400">Production mensuelle</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3 text-center">
              <div className="text-sm font-medium text-amber-600">-62%</div>
              <div className="text-xs text-gray-400">Coût vs fourrage marché</div>
            </div>
          </div>
        </div>
      </div>

      {/* Ligne 5 : Finance + Tâches */}
      <div className="grid grid-cols-3 gap-4">
        {/* Finance */}
        <div className="col-span-2 card">
          <div className="flex items-center justify-between mb-4">
            <div className="font-medium text-sm">Finance — Jan 2025</div>
            <span className="text-xs text-gray-400">DZD</span>
          </div>
          <div className="grid grid-cols-4 gap-3 mb-4">
            {[
              { label: 'VENTES VIANDE', value: '824 k', sub: '↑ +11%', color: 'text-green-700' },
              { label: 'REPRODUCTEURS', value: '380 k', sub: '3 animaux', color: 'text-green-700' },
              { label: 'FOURRAGE', value: '142 k', sub: '↑ excédent', color: 'text-amber-600' },
              { label: 'SOUS-PRODUITS', value: '74 k', sub: 'Laine, fumier', color: 'text-gray-400' },
            ].map((f, i) => (
              <div key={i} className="kpi-card">
                <div className="kpi-label">{f.label}</div>
                <div className={`text-lg font-medium ${f.color}`}>{f.value}</div>
                <div className="text-xs text-gray-400 mt-0.5">{f.sub}</div>
              </div>
            ))}
          </div>
          <ResponsiveContainer width="100%" height={100}>
            <LineChart data={cheptelData.slice(0, 5)} margin={{ top: 0, right: 0, bottom: 0, left: -25 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="mois" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 9 }} />
              <Tooltip />
              <Line type="monotone" dataKey="ca" name="CA (k DZD)" stroke="#1D9E75" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Tâches du jour */}
        <div className="card">
          <div className="font-medium text-sm mb-4">Tâches du jour</div>
          <div className="space-y-2">
            {[
              { done: true, text: 'Vaccination lot B-02 (38 têtes)', tag: 'Santé', tagColor: '' },
              { done: false, text: 'Isoler EOI-0247 — Score 82', tag: 'Urgent', tagColor: 'text-red-600 bg-red-50' },
              { done: false, text: 'Lancer cycle hydroponie C-12', tag: 'Hydro', tagColor: '' },
              { done: false, text: 'Pesée agneaux lot G1 (31 têtes)', tag: 'Cheptel', tagColor: '' },
              { done: false, text: 'Relevé capteur T° Bergerie B', tag: 'IoT', tagColor: '' },
            ].map((t, i) => (
              <div key={i} className="flex items-center gap-3 py-1.5 border-b border-gray-50 last:border-0">
                <div className={`w-4 h-4 rounded flex items-center justify-center flex-shrink-0 ${t.done ? 'bg-green-500' : 'border border-gray-200'}`}>
                  {t.done && <span className="text-white text-xs">✓</span>}
                </div>
                <span className={`text-xs flex-1 ${t.done ? 'line-through text-gray-400' : t.tag === 'Urgent' ? 'text-red-600 font-medium' : ''}`}>
                  {t.text}
                </span>
                <span className={`text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-500 ${t.tagColor}`}>
                  {t.tag}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

    </div>
  )
}
