'use client'
// app/dashboard/iot/page.tsx

export default function IoTPage() {
  const capteurs = [
    { code:'T-BA-01', type:'Température', lieu:'Bergerie A', valeur:'23.4°C', statut:'Normal', ok:true, batterie:92 },
    { code:'T-BB-01', type:'Température', lieu:'Bergerie B', valeur:'38.9°C', statut:'ALERTE', ok:false, batterie:87 },
    { code:'T-BC-01', type:'Température', lieu:'Bergerie C', valeur:'22.1°C', statut:'Normal', ok:true, batterie:95 },
    { code:'H-BA-01', type:'Humidité', lieu:'Bergerie A', valeur:'65%', statut:'Normal', ok:true, batterie:88 },
    { code:'H-BB-01', type:'Humidité', lieu:'Bergerie B', valeur:'72%', statut:'Vigilance', ok:null, batterie:91 },
    { code:'W-MAIN-01', type:'Eau', lieu:'Réseau principal', valeur:'8 200 L', statut:'Normal', ok:true, batterie:100 },
    { code:'W-HYDRO-01', type:'Eau', lieu:'Hydroponique', valeur:'1 240 L', statut:'Normal', ok:true, batterie:100 },
    { code:'S-SOL-01', type:'Solaire', lieu:'Toiture', valeur:'312 kWh', statut:'Normal', ok:true, batterie:100 },
    { code:'P-BAS-01', type:'Poids bascule', lieu:'Couloir pesée', valeur:'Prêt', statut:'Normal', ok:true, batterie:76 },
    { code:'CO2-BA-01', type:'CO2', lieu:'Bergerie A', valeur:'820 ppm', statut:'Normal', ok:true, batterie:83 },
    { code:'ACT-BA-01', type:'Activité', lieu:'Bergerie A', valeur:'Score 68', statut:'Normal', ok:true, batterie:79 },
    { code:'ACT-BB-01', type:'Activité', lieu:'Bergerie B', valeur:'Score 42', statut:'Vigilance', ok:null, batterie:81 },
  ]

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">IoT — Tableau de bord capteurs</h1>
          <p className="text-sm text-gray-500 mt-0.5">118/120 capteurs actifs · Dernière lecture il y a 23 secondes</p>
        </div>
        <div className="flex gap-3">
          <span className="flex items-center gap-2 text-xs text-green-700 border border-green-200 px-3 py-2 rounded-lg">
            <span className="w-2 h-2 bg-green-500 rounded-full pulse-dot"></span>
            Temps réel actif
          </span>
          <button className="btn-outline text-sm">📄 Rapport IoT</button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="kpi-card"><div className="kpi-label">CAPTEURS ACTIFS</div><div className="kpi-value">118/120</div></div>
        <div className="kpi-card"><div className="kpi-label">ALERTES ACTIVES</div><div className="kpi-value text-red-600">2</div></div>
        <div className="kpi-card"><div className="kpi-label">ANOMALIES AUJOURD'HUI</div><div className="kpi-value text-amber-600">5</div></div>
        <div className="kpi-card"><div className="kpi-label">PRÉCISION IA</div><div className="kpi-value">97.3%</div></div>
      </div>

      <div className="card overflow-hidden p-0">
        <table className="data-table">
          <thead>
            <tr className="bg-gray-50">
              <th>Code capteur</th>
              <th>Type</th>
              <th>Emplacement</th>
              <th>Valeur actuelle</th>
              <th>Statut</th>
              <th>Batterie</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {capteurs.map((c, i) => (
              <tr key={i}>
                <td className="font-medium text-xs">{c.code}</td>
                <td className="text-xs">{c.type}</td>
                <td className="text-xs">{c.lieu}</td>
                <td className="font-medium text-sm" style={{ color: c.ok === false ? '#E24B4A' : c.ok === null ? '#BA7517' : '#0F6E56' }}>{c.valeur}</td>
                <td>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${c.ok === false ? 'badge-red' : c.ok === null ? 'badge-amber' : 'badge-green'}`}>
                    {c.statut}
                  </span>
                </td>
                <td>
                  <div className="flex items-center gap-2">
                    <div className="w-12 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-green-500" style={{ width: `${c.batterie}%` }}></div>
                    </div>
                    <span className="text-xs text-gray-400">{c.batterie}%</span>
                  </div>
                </td>
                <td><button className="text-xs text-green-700 hover:underline">Historique</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
