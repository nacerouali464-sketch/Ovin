'use client'
// app/dashboard/esg/page.tsx

export default function ESGPage() {
  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium">Rapport ESG</h1>
          <p className="text-sm text-gray-500 mt-0.5">Environnement · Social · Gouvernance — Année 2025</p>
        </div>
        <button className="btn-outline text-sm">📄 Exporter rapport ESG</button>
      </div>

      <div className="grid grid-cols-3 gap-6 mb-6">
        {/* Environnement */}
        <div className="card border-l-4 border-l-green-500">
          <div className="font-medium text-sm text-green-700 mb-4">🌿 Environnement</div>
          <div className="space-y-3">
            {[
              { label: 'CO₂ évité (énergie solaire)', value: '49,2 t/an', up: true },
              { label: 'Eau recyclée (hydroponie)', value: '92% vs élevage conv.', up: true },
              { label: 'Consommation eau / animal', value: '18 L/jour', up: true },
              { label: 'Autonomie énergétique', value: '85%', up: true },
              { label: 'Déchets organiques valorisés', value: '100% (fumier)', up: true },
            ].map((e, i) => (
              <div key={i} className="flex justify-between items-center py-1 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">{e.label}</span>
                <span className="text-xs font-medium text-green-700">{e.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Social */}
        <div className="card border-l-4 border-l-blue-400">
          <div className="font-medium text-sm text-blue-600 mb-4">👥 Social</div>
          <div className="space-y-3">
            {[
              { label: 'Emplois directs créés', value: '12 postes' },
              { label: 'Emplois indirects', value: '~35 postes' },
              { label: 'Masse salariale / mois', value: '780 000 DZD' },
              { label: 'Formation professionnelle', value: '3 sessions/an' },
              { label: 'Origine main d\'œuvre', value: '100% locale SBA' },
              { label: 'Femmes employées', value: '4 (33%)' },
            ].map((s, i) => (
              <div key={i} className="flex justify-between items-center py-1 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">{s.label}</span>
                <span className="text-xs font-medium text-blue-600">{s.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Gouvernance */}
        <div className="card border-l-4 border-l-amber-400">
          <div className="font-medium text-sm text-amber-600 mb-4">🏛 Gouvernance</div>
          <div className="space-y-3">
            {[
              { label: 'Traçabilité animaux', value: '100% RFID' },
              { label: 'Certifications obtenues', value: 'Halal, Origine Algérie' },
              { label: 'Audit vétérinaire', value: 'Mensuel' },
              { label: 'Rapport financier', value: 'Trimestriel' },
              { label: 'Logs d\'audit système', value: 'Toutes actions tracées' },
              { label: 'Conformité réglementaire', value: '✓ MADR 2024' },
            ].map((g, i) => (
              <div key={i} className="flex justify-between items-center py-1 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">{g.label}</span>
                <span className="text-xs font-medium text-amber-600">{g.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Score ESG global */}
      <div className="card">
        <div className="font-medium text-sm mb-4">Score ESG global — Élevage Ovin Intelligent</div>
        <div className="grid grid-cols-3 gap-6">
          {[
            { label: 'Score Environnement', score: 82, color: '#1D9E75', detail: 'Énergie solaire, eau, déchets' },
            { label: 'Score Social', score: 74, color: '#378ADD', detail: 'Emploi local, formation, genre' },
            { label: 'Score Gouvernance', score: 88, color: '#BA7517', detail: 'Traçabilité, conformité, audit' },
          ].map((s, i) => (
            <div key={i} className="text-center">
              <div className="text-3xl font-medium mb-1" style={{ color: s.color }}>{s.score}/100</div>
              <div className="font-medium text-sm mb-1">{s.label}</div>
              <div className="text-xs text-gray-400">{s.detail}</div>
              <div className="mt-3 h-2 bg-gray-100 rounded-full overflow-hidden">
                <div className="h-full rounded-full" style={{ width: `${s.score}%`, backgroundColor: s.color }}></div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 pt-4 border-t border-gray-100 text-center">
          <span className="text-2xl font-medium text-green-700">Score global : 81/100</span>
          <span className="ml-3 badge-green">Niveau A — Très bon</span>
        </div>
      </div>
    </div>
  )
}
