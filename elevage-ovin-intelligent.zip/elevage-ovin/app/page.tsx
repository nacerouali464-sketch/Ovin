'use client'
// app/page.tsx — Landing page publique

import Link from 'next/link'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-8 py-4 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-green-700 rounded-lg flex items-center justify-center">
            <span className="text-white text-lg">🐑</span>
          </div>
          <div>
            <div className="font-medium text-sm">Élevage Ovin Intelligent</div>
            <div className="text-xs text-gray-500">Sidi Bel Abbès, Algérie</div>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <a href="#technologie" className="text-sm text-gray-500 hover:text-green-700">Technologie</a>
          <a href="#investisseurs" className="text-sm text-gray-500 hover:text-green-700">Investisseurs</a>
          <a href="#contact" className="text-sm text-gray-500 hover:text-green-700">Contact</a>
          <Link href="/auth/login" className="btn-primary">
            Accéder à la plateforme →
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="text-center px-8 py-20 max-w-4xl mx-auto">
        <div className="badge-green inline-block mb-4">AgriTech · Algérie · Sidi Bel Abbès</div>
        <h1 className="text-5xl font-medium text-gray-900 leading-tight mb-6">
          L'élevage ovin <span className="text-green-700">intelligent</span><br />nouvelle génération
        </h1>
        <p className="text-xl text-gray-500 mb-10 max-w-2xl mx-auto leading-relaxed">
          Pilotage intégral de votre exploitation ovine grâce à l'IoT, l'IA et l'hydroponie. 
          De 500 à 3 500 têtes en 5 ans, avec un TRI certifié de 15%.
        </p>
        <div className="flex gap-4 justify-center">
          <Link href="/auth/login" className="btn-primary text-base px-8 py-3">
            Voir le dashboard exécutif →
          </Link>
          <a href="#investisseurs" className="btn-outline text-base px-8 py-3">
            Dossier investisseur
          </a>
        </div>
      </section>

      {/* KPI Band */}
      <div className="grid grid-cols-6 border-t border-b border-gray-100">
        {[
          { num: '500', label: 'Brebis initiales' },
          { num: '3 500', label: 'Têtes à 5 ans' },
          { num: '78,25 M', label: 'CA cible (DZD)' },
          { num: '15%', label: 'TRI' },
          { num: '35 M', label: 'Investissement (DZD)' },
          { num: '100%', label: 'Énergie solaire' },
        ].map((kpi, i) => (
          <div key={i} className="text-center py-8 border-r border-gray-100 last:border-r-0">
            <div className="text-2xl font-medium text-green-700">{kpi.num}</div>
            <div className="text-xs text-gray-500 mt-1">{kpi.label}</div>
          </div>
        ))}
      </div>

      {/* Modules */}
      <section className="px-8 py-16 max-w-6xl mx-auto" id="technologie">
        <div className="text-xs font-medium text-gray-400 uppercase tracking-widest mb-2">Modules de la plateforme</div>
        <h2 className="text-3xl font-medium mb-2">15 modules intégrés</h2>
        <p className="text-gray-500 mb-10">Une solution bout-en-bout pour gérer chaque dimension de votre exploitation</p>
        <div className="grid grid-cols-5 gap-4">
          {[
            { icon: '🐑', title: 'Cheptel', desc: 'Fiches, généalogie, poids, statut, historique' },
            { icon: '🧬', title: 'Reproduction', desc: 'Chaleurs, gestation, agnelages, fertilité' },
            { icon: '💉', title: 'Santé', desc: 'Vaccins, traitements, alertes maladies' },
            { icon: '🌿', title: 'Nutrition', desc: 'Rations par profil, coût alimentaire IA' },
            { icon: '💧', title: 'Hydroponie', desc: 'Cycles 7-10j, volumes, stocks fourrage' },
            { icon: '📡', title: 'IoT', desc: 'Capteurs biométriques, anomalies temps réel' },
            { icon: '☀️', title: 'Énergie solaire', desc: 'Production, consommation, économies' },
            { icon: '📊', title: 'Finance', desc: 'CAPEX, OPEX, ventes, marges, cash-flow' },
            { icon: '🔏', title: 'Traçabilité', desc: 'Lots, certifications, QR code, historique' },
            { icon: '🌱', title: 'ESG', desc: 'Emploi, eau, carbone, économie circulaire' },
          ].map((mod, i) => (
            <Link href="/auth/login" key={i} className="card hover:border-green-200 hover:shadow-sm transition-all cursor-pointer">
              <div className="text-2xl mb-3">{mod.icon}</div>
              <div className="font-medium text-sm mb-1">{mod.title}</div>
              <div className="text-xs text-gray-500 leading-relaxed">{mod.desc}</div>
            </Link>
          ))}
        </div>
      </section>

      {/* IA */}
      <section className="bg-gray-50 px-8 py-16">
        <div className="max-w-6xl mx-auto">
          <div className="text-xs font-medium text-gray-400 uppercase tracking-widest mb-2">Intelligence artificielle</div>
          <h2 className="text-3xl font-medium mb-10">IA embarquée à chaque niveau</h2>
          <div className="grid grid-cols-3 gap-6">
            {[
              { title: 'Détection précoce des maladies', desc: 'Analyse biométrique 48h avant symptômes visibles', stat: 'Précision 89%' },
              { title: 'Scoring de risque animal', desc: 'Score 0-100 par animal, actualisé toutes les 4h', stat: 'Temps réel' },
              { title: 'Prévision fertilité', desc: 'Fenêtres de chaleur prédites 3 jours à l\'avance', stat: '+22% fertilité' },
              { title: 'Optimisation rations', desc: 'Calcul automatique selon profil, stade, prix marché', stat: '-18% coût' },
              { title: 'Détection anomalies IoT', desc: 'Surveillance 120+ capteurs, alerte en 2 minutes', stat: '120 capteurs' },
              { title: 'Recommandations actions', desc: 'Tâches prioritaires générées chaque matin pour l\'équipe', stat: 'Auto' },
            ].map((ai, i) => (
              <div key={i} className="card">
                <div className="font-medium text-sm mb-2">{ai.title}</div>
                <div className="text-xs text-gray-500 mb-3 leading-relaxed">{ai.desc}</div>
                <span className="badge-green">{ai.stat}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Investisseurs */}
      <section className="px-8 py-16 max-w-6xl mx-auto" id="investisseurs">
        <div className="text-xs font-medium text-gray-400 uppercase tracking-widest mb-2">Investissement</div>
        <h2 className="text-3xl font-medium mb-10">Indicateurs financiers du projet</h2>
        <div className="grid grid-cols-4 gap-6 mb-12">
          {[
            { num: '35 M DZD', desc: 'Investissement total CAPEX · Infrastructures, énergie solaire, IoT, hydroponie', featured: true },
            { num: '78,25 M', desc: 'Chiffre d\'affaires cible année 5 · Viande, reproducteurs, fourrage, sous-produits', featured: false },
            { num: '15%', desc: 'Taux de Retour sur Investissement · Horizon 7 ans, scénario central', featured: false },
            { num: '3 500', desc: 'Taille cible du cheptel en année 5 · Depuis 500 têtes initiales', featured: false },
          ].map((inv, i) => (
            <div key={i} className={`card ${inv.featured ? 'border-green-300 border-2' : ''}`}>
              <div className="text-3xl font-medium text-green-700 mb-2">{inv.num}</div>
              <div className="text-xs text-gray-500 leading-relaxed">{inv.desc}</div>
            </div>
          ))}
        </div>

        {/* Timeline */}
        <div className="space-y-6">
          {[
            { year: 'A1', title: 'Démarrage — 500 têtes', desc: 'Infrastructure, énergie solaire 80 kWc, hydroponie 500 m², IoT déployé, 1er agnelage' },
            { year: 'A2', title: 'Consolidation — 1 200 têtes', desc: 'Première vente de reproducteurs certifiés, optimisation rations IA, CA 18 M DZD' },
            { year: 'A3', title: 'Accélération — 2 000 têtes', desc: 'Diversification produits, fourrage excédentaire vendu, CA 38 M DZD' },
            { year: 'A4', title: 'Maturité — 2 800 têtes', desc: 'Certification traçabilité, export potentiel, CA 58 M DZD, atteinte seuil TRI' },
            { year: 'A5', title: 'Performance optimale — 3 500 têtes', desc: 'CA 78,25 M DZD, autonomie énergétique totale, référence nationale AgriTech' },
          ].map((tl, i) => (
            <div key={i} className="flex gap-6 items-start">
              <div className="w-10 h-10 bg-green-50 border-2 border-green-200 rounded-full flex items-center justify-center text-xs font-medium text-green-700 flex-shrink-0">
                {tl.year}
              </div>
              <div>
                <div className="font-medium text-sm mb-1">{tl.title}</div>
                <div className="text-xs text-gray-500">{tl.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-green-700 px-8 py-16 text-center" id="contact">
        <h2 className="text-3xl font-medium text-white mb-4">Prêt à piloter votre exploitation ?</h2>
        <p className="text-green-100 mb-8 text-lg">Accédez au dashboard avec données simulées réalistes — aucune installation requise.</p>
        <Link href="/auth/login" className="bg-white text-green-700 px-10 py-4 rounded-lg font-medium text-lg hover:bg-green-50 transition-colors inline-block">
          Lancer le dashboard complet →
        </Link>
        <div className="mt-10 text-green-200 text-sm">
          Élevage Ovin Intelligent · Sidi Bel Abbès, Algérie · AgriTech 2025
        </div>
      </section>
    </div>
  )
}
