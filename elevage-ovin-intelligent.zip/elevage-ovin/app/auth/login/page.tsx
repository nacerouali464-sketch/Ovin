'use client'
// app/auth/login/page.tsx

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    const supabase = createClient()
    const { error } = await supabase.auth.signInWithPassword({ email, password })

    if (error) {
      setError('Email ou mot de passe incorrect')
      setLoading(false)
      return
    }

    router.push('/dashboard')
  }

  // Connexion démo rapide
  const loginDemo = async (role: string) => {
    setLoading(true)
    const demos: Record<string, { email: string; password: string }> = {
      directeur: { email: 'directeur@eoi-sba.dz', password: 'demo123456' },
      elevage: { email: 'eleveur@eoi-sba.dz', password: 'demo123456' },
      vet: { email: 'vet@eoi-sba.dz', password: 'demo123456' },
    }
    const creds = demos[role]
    setEmail(creds.email)
    setPassword(creds.password)
    // En mode démo, on redirige directement
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 bg-green-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">🐑</span>
          </div>
          <h1 className="text-2xl font-medium text-gray-900">Élevage Ovin Intelligent</h1>
          <p className="text-gray-500 text-sm mt-1">Sidi Bel Abbès, Algérie</p>
        </div>

        {/* Formulaire */}
        <div className="card shadow-sm">
          <h2 className="font-medium text-lg mb-6">Connexion</h2>

          {error && (
            <div className="bg-red-50 text-red-700 text-sm px-4 py-3 rounded-lg mb-4">
              {error}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-700 block mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-green-500"
                placeholder="votre@email.dz"
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 block mb-1">Mot de passe</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-green-500"
                placeholder="••••••••"
                required
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary py-3 text-base disabled:opacity-50"
            >
              {loading ? 'Connexion...' : 'Se connecter'}
            </button>
          </form>

          {/* Connexions démo */}
          <div className="mt-6 pt-6 border-t border-gray-100">
            <p className="text-xs text-gray-400 text-center mb-3">Accès démo rapide</p>
            <div className="grid grid-cols-3 gap-2">
              <button onClick={() => loginDemo('directeur')} className="text-xs border border-gray-200 rounded-lg py-2 hover:bg-green-50 hover:border-green-200 transition-colors">
                👔 Directeur
              </button>
              <button onClick={() => loginDemo('elevage')} className="text-xs border border-gray-200 rounded-lg py-2 hover:bg-green-50 hover:border-green-200 transition-colors">
                🐑 Éleveur
              </button>
              <button onClick={() => loginDemo('vet')} className="text-xs border border-gray-200 rounded-lg py-2 hover:bg-green-50 hover:border-green-200 transition-colors">
                💉 Vétérinaire
              </button>
            </div>
          </div>
        </div>

        <div className="text-center mt-6">
          <Link href="/" className="text-sm text-gray-400 hover:text-green-700">← Retour au site</Link>
        </div>
      </div>
    </div>
  )
}
