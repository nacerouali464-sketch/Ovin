// middleware.ts — Protection des routes par rôle
import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs'
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// Routes publiques (pas besoin d'être connecté)
const PUBLIC_ROUTES = ['/', '/technologie', '/investisseurs', '/contact', '/auth/login']

// Permissions par rôle
const ROLE_PERMISSIONS: Record<string, string[]> = {
  admin: ['*'],
  directeur: ['/dashboard', '/cheptel', '/reproduction', '/sante', '/nutrition', '/hydroponie', '/iot', '/energie', '/finance', '/tracabilite', '/esg', '/alertes'],
  responsable_elevage: ['/dashboard', '/cheptel', '/reproduction', '/sante', '/nutrition', '/hydroponie', '/alertes'],
  veterinaire: ['/dashboard', '/cheptel', '/sante', '/reproduction', '/alertes'],
  technicien_iot: ['/dashboard', '/iot', '/energie', '/alertes'],
}

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })
  
  const { data: { session } } = await supabase.auth.getSession()
  const path = req.nextUrl.pathname

  // Laisser passer les routes publiques
  if (PUBLIC_ROUTES.some(route => path === route || path.startsWith('/auth'))) {
    return res
  }

  // Rediriger vers login si pas connecté
  if (!session) {
    return NextResponse.redirect(new URL('/auth/login', req.url))
  }

  // Vérifier le rôle
  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', session.user.id)
    .single()

  if (!profile) {
    return NextResponse.redirect(new URL('/auth/login', req.url))
  }

  const role = profile.role
  const permissions = ROLE_PERMISSIONS[role] || []

  // Admin a accès à tout
  if (permissions.includes('*')) return res

  // Vérifier si le rôle a accès à cette route
  const hasAccess = permissions.some(p => path.startsWith(p))
  if (!hasAccess) {
    return NextResponse.redirect(new URL('/dashboard', req.url))
  }

  return res
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|api).*)'],
}
