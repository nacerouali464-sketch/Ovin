// lib/ai/riskScoring.ts — Scoring santé animal

interface AnimalMetrics {
  animalId: string
  temperatureRectal: number    // normal: 38.0–39.5°C
  activityLevel: number        // 0-100, normal: 40-80
  feedIntakeRatio: number      // ratio vs ration normale: normal 0.8-1.2
  respiratoryRate: number      // respirations/min, normal: 12-20
  ageMonths: number
  daysPostPartum?: number
  gestationWeek?: number
  historicalIncidents: number  // incidents 12 derniers mois
}

interface RiskResult {
  score: number
  level: 'faible' | 'modere' | 'eleve' | 'critique'
  factors: string[]
  recommendation: string
  urgency: 'normal' | 'surveiller' | 'urgent' | 'immediat'
}

export function computeRiskScore(metrics: AnimalMetrics): RiskResult {
  let score = 0
  const factors: string[] = []

  // Température rectale (poids: 30 pts)
  if (metrics.temperatureRectal > 40.5) {
    score += 30; factors.push('Hyperthermie sévère (>40.5°C)')
  } else if (metrics.temperatureRectal > 39.8) {
    score += 18; factors.push('Température élevée (>39.8°C)')
  } else if (metrics.temperatureRectal > 39.5) {
    score += 8; factors.push('Légère hyperthermie')
  } else if (metrics.temperatureRectal < 37.5) {
    score += 20; factors.push('Hypothermie (<37.5°C)')
  }

  // Niveau d'activité (poids: 20 pts)
  if (metrics.activityLevel < 20) {
    score += 20; factors.push('Activité très faible (<20%)')
  } else if (metrics.activityLevel < 35) {
    score += 12; factors.push('Activité réduite (<35%)')
  } else if (metrics.activityLevel < 45) {
    score += 5; factors.push('Activité légèrement basse')
  }

  // Prise alimentaire (poids: 20 pts)
  if (metrics.feedIntakeRatio < 0.5) {
    score += 20; factors.push('Anorexie sévère (<50% ration)')
  } else if (metrics.feedIntakeRatio < 0.7) {
    score += 10; factors.push('Réduction d\'appétit (<70%)')
  } else if (metrics.feedIntakeRatio < 0.8) {
    score += 5; factors.push('Légère réduction appétit')
  }

  // Fréquence respiratoire (poids: 15 pts)
  if (metrics.respiratoryRate > 35) {
    score += 15; factors.push('Polypnée sévère (>35/min)')
  } else if (metrics.respiratoryRate > 28) {
    score += 10; factors.push('Polypnée modérée (>28/min)')
  } else if (metrics.respiratoryRate > 22) {
    score += 5; factors.push('Légère polypnée')
  }

  // Facteurs aggravants (poids: 15 pts)
  if (metrics.historicalIncidents >= 4) {
    score += 10; factors.push('Antécédents fréquents (≥4)')
  } else if (metrics.historicalIncidents >= 2) {
    score += 5; factors.push('Quelques antécédents')
  }
  if (metrics.daysPostPartum !== undefined && metrics.daysPostPartum < 7) {
    score += 5; factors.push('Post-partum précoce (<7j)')
  }
  if (metrics.ageMonths > 84) {
    score += 5; factors.push('Animal âgé (>7 ans)')
  }
  if (metrics.gestationWeek !== undefined && metrics.gestationWeek > 18) {
    score += 3; factors.push('Gestation avancée (>S18)')
  }

  const finalScore = Math.min(score, 100)

  const level: RiskResult['level'] =
    finalScore >= 70 ? 'critique' :
    finalScore >= 50 ? 'eleve' :
    finalScore >= 30 ? 'modere' : 'faible'

  const urgency: RiskResult['urgency'] =
    finalScore >= 70 ? 'immediat' :
    finalScore >= 50 ? 'urgent' :
    finalScore >= 30 ? 'surveiller' : 'normal'

  const recommendation =
    finalScore >= 70 ? 'Isolement immédiat + consultation vétérinaire urgente (< 2h)' :
    finalScore >= 50 ? 'Surveillance rapprochée, prévenir le vétérinaire dans la journée' :
    finalScore >= 30 ? 'Surveillance accrue 2x/jour, noter l\'évolution' :
    'Surveillance normale lors des rondes quotidiennes'

  return { score: finalScore, level, factors, recommendation, urgency }
}

// lib/ai/rationOptimizer.ts — Optimisation des rations alimentaires

interface NutritionProfile {
  profileName: string
  animalCount: number
  stage: 'entretien' | 'gestation_debut' | 'gestation_fin' | 'lactation' | 'croissance' | 'engraissement'
  targetWeight: number        // kg
  currentWeight: number       // kg
  season: 'hiver' | 'printemps' | 'ete' | 'automne'
}

interface IngredientPrice {
  foin: number                // DZD/kg
  orge: number
  hydroponique: number
  cmv: number
  son_ble: number
}

interface OptimizedRation {
  ingredients: Array<{ name: string; qty_kg: number; cost_dzd: number }>
  total_kg: number
  total_cost_dzd: number
  cost_per_animal: number
  savings_vs_standard_pct: number
  nutritional_notes: string[]
}

export function optimizeRation(
  profile: NutritionProfile,
  prices: IngredientPrice
): OptimizedRation {
  // Besoins de base selon stade physiologique
  const baseNeeds = {
    entretien:        { dm: 1.5, protein: 0.11, energy: 9.0 },
    gestation_debut:  { dm: 1.8, protein: 0.13, energy: 9.8 },
    gestation_fin:    { dm: 2.1, protein: 0.15, energy: 11.0 },
    lactation:        { dm: 2.4, protein: 0.16, energy: 12.0 },
    croissance:       { dm: 1.2, protein: 0.18, energy: 12.5 },
    engraissement:    { dm: 1.8, protein: 0.16, energy: 13.0 },
  }

  const needs = baseNeeds[profile.stage]

  // Ration optimisée avec fourrage hydroponique (réduction coût -18%)
  const hydroRatio = profile.season === 'ete' ? 0.25 : 0.15
  const hayRatio = 0.55 - hydroRatio * 0.3
  const grainRatio = 0.30
  const cmvRatio = 0.05
  const branRatio = 0.10

  const ration = [
    { name: 'Foin de qualité', qty_kg: needs.dm * hayRatio, cost_dzd: needs.dm * hayRatio * prices.foin },
    { name: 'Orge concassée', qty_kg: needs.dm * grainRatio, cost_dzd: needs.dm * grainRatio * prices.orge },
    { name: 'Fourrage hydroponique', qty_kg: needs.dm * hydroRatio, cost_dzd: needs.dm * hydroRatio * prices.hydroponique },
    { name: 'CMV ovin', qty_kg: needs.dm * cmvRatio, cost_dzd: needs.dm * cmvRatio * prices.cmv },
    { name: 'Son de blé', qty_kg: needs.dm * branRatio, cost_dzd: needs.dm * branRatio * prices.son_ble },
  ]

  const totalKg = ration.reduce((s, i) => s + i.qty_kg, 0)
  const totalCost = ration.reduce((s, i) => s + i.cost_dzd, 0)
  const standardCost = totalCost * 1.22 // +22% sans optimisation

  return {
    ingredients: ration.map(r => ({ ...r, qty_kg: Math.round(r.qty_kg * 100) / 100, cost_dzd: Math.round(r.cost_dzd * 10) / 10 })),
    total_kg: Math.round(totalKg * 100) / 100,
    total_cost_dzd: Math.round(totalCost * 10) / 10,
    cost_per_animal: Math.round(totalCost * 10) / 10,
    savings_vs_standard_pct: Math.round((1 - totalCost / standardCost) * 100),
    nutritional_notes: [
      `Ration calculée pour stade : ${profile.stage}`,
      `Fourrage hydroponique : ${Math.round(hydroRatio * 100)}% de la ration (réduction coût)`,
      `Protéines brutes estimées : ${Math.round(needs.protein * 100)}%`,
    ]
  }
}

// lib/ai/fertilityPredict.ts — Prévision fertilité

interface FertilityInput {
  animalId: string
  lastHeatDate?: Date
  cycleLength: number           // jours, normal: 17-21
  bodyConditionScore: number    // 1-5
  lastLitterSize?: number
  ageMonths: number
  nutritionScore: number        // 0-100
  seasonMonth: number           // 1-12
}

interface FertilityPrediction {
  nextHeatDate: Date
  confidenceScore: number       // 0-100
  predictedLitterSize: number
  fertilityRisk: 'faible' | 'modere' | 'eleve'
  recommendations: string[]
}

export function predictFertility(input: FertilityInput): FertilityPrediction {
  const now = new Date()
  const lastHeat = input.lastHeatDate || new Date(now.getTime() - input.cycleLength * 24 * 3600 * 1000)
  const nextHeat = new Date(lastHeat.getTime() + input.cycleLength * 24 * 3600 * 1000)

  // Score de confiance basé sur régularité des cycles
  let confidence = 75
  if (input.bodyConditionScore >= 3.0 && input.bodyConditionScore <= 3.5) confidence += 10
  if (input.nutritionScore >= 70) confidence += 8
  if (input.ageMonths >= 18 && input.ageMonths <= 60) confidence += 7
  if (input.seasonMonth >= 8 && input.seasonMonth <= 12) confidence += 5 // Saison de reproduction

  // Taille de portée prévue
  let litterSize = 1.4 // Base Ouled Djellal
  if (input.bodyConditionScore >= 3.5) litterSize += 0.2
  if (input.lastLitterSize && input.lastLitterSize >= 2) litterSize += 0.1

  const risk = confidence < 60 ? 'eleve' : confidence < 75 ? 'modere' : 'faible'

  const recommendations: string[] = []
  if (input.bodyConditionScore < 2.5) recommendations.push('Améliorer score corporel avant la lutte (+0.5 UB)')
  if (input.nutritionScore < 60) recommendations.push('Augmenter ration énergétique 2 semaines avant saillie (flushing)')
  if (input.cycleLength > 21) recommendations.push('Cycle irrégulier — surveillance accrue recommandée')

  return {
    nextHeatDate: nextHeat,
    confidenceScore: Math.min(confidence, 98),
    predictedLitterSize: Math.round(litterSize * 10) / 10,
    fertilityRisk: risk,
    recommendations,
  }
}
