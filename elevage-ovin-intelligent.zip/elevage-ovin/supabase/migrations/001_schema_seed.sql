-- ============================================
-- ÉLEVAGE OVIN INTELLIGENT — Schéma complet
-- Supabase / PostgreSQL
-- Exécuter dans SQL Editor de Supabase
-- ============================================

-- TYPES ÉNUMÉRÉS
CREATE TYPE user_role AS ENUM ('admin','directeur','responsable_elevage','veterinaire','technicien_iot');
CREATE TYPE animal_sex AS ENUM ('M','F');
CREATE TYPE animal_status AS ENUM ('actif','gestante','allaitante','malade','quarantaine','vendu','mort');
CREATE TYPE health_record_type AS ENUM ('vaccination','traitement','visite_veterinaire','chirurgie','diagnostic','deces','quarantaine');
CREATE TYPE repro_status AS ENUM ('chaleur_detectee','saillie','gestation_confirmee','gestation_avancee','agnelage','avortement','non_gestante');
CREATE TYPE sensor_type AS ENUM ('temperature','humidite','eau_consommation','activite','poids_bascule','co2','lumiere','solaire_production');
CREATE TYPE product_type AS ENUM ('viande_ovine','reproducteur_male','reproducteur_femelle','fourrage','laine','fumier','autre');
CREATE TYPE alert_severity AS ENUM ('critique','eleve','modere','info');
CREATE TYPE alert_module AS ENUM ('sante','iot','reproduction','hydroponie','energie','nutrition','finance','ia','systeme');

-- PROFILS UTILISATEURS
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users,
  full_name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'technicien_iot',
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  last_active TIMESTAMPTZ
);

-- ANIMAUX
CREATE TABLE animals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ear_tag TEXT UNIQUE NOT NULL,
  rfid_tag TEXT UNIQUE,
  name TEXT,
  breed TEXT NOT NULL,
  sex animal_sex NOT NULL,
  birth_date DATE NOT NULL,
  mother_id UUID REFERENCES animals(id),
  father_id UUID REFERENCES animals(id),
  pen_id TEXT,
  status animal_status DEFAULT 'actif',
  current_weight_kg DECIMAL(6,2),
  purchase_price_dzd DECIMAL(12,2),
  ai_risk_score INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- POIDS HISTORIQUE
CREATE TABLE weight_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  animal_id UUID REFERENCES animals(id) ON DELETE CASCADE,
  weight_kg DECIMAL(6,2) NOT NULL,
  recorded_at TIMESTAMPTZ DEFAULT NOW(),
  recorded_by UUID REFERENCES profiles(id)
);

-- REPRODUCTION
CREATE TABLE reproductions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  female_id UUID REFERENCES animals(id) ON DELETE CASCADE,
  male_id UUID REFERENCES animals(id),
  heat_date DATE,
  mating_date DATE,
  gestation_start DATE,
  expected_birth DATE,
  actual_birth DATE,
  litter_size INTEGER,
  male_lambs INTEGER,
  female_lambs INTEGER,
  stillborn INTEGER DEFAULT 0,
  status repro_status DEFAULT 'chaleur_detectee',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- SANTÉ
CREATE TABLE health_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  animal_id UUID REFERENCES animals(id) ON DELETE CASCADE,
  type health_record_type NOT NULL,
  date DATE NOT NULL,
  diagnosis TEXT,
  treatment TEXT,
  medication TEXT,
  dosage TEXT,
  vet_id UUID REFERENCES profiles(id),
  cost_dzd DECIMAL(10,2),
  follow_up_date DATE,
  resolved BOOLEAN DEFAULT FALSE,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- NUTRITION
CREATE TABLE feed_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  daily_ration_kg DECIMAL(6,3) NOT NULL,
  cost_per_kg_dzd DECIMAL(8,2) NOT NULL,
  ingredients JSONB
);

CREATE TABLE daily_feed_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  pen_id TEXT NOT NULL,
  profile_id UUID REFERENCES feed_profiles(id),
  head_count INTEGER NOT NULL,
  total_qty_kg DECIMAL(10,3),
  total_cost_dzd DECIMAL(12,2),
  recorded_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- HYDROPONIE
CREATE TABLE hydro_cycles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_number INTEGER NOT NULL,
  start_date DATE NOT NULL,
  expected_end_date DATE,
  actual_end_date DATE,
  tray_count INTEGER NOT NULL,
  seed_qty_kg DECIMAL(8,2),
  water_used_liters DECIMAL(10,2),
  yield_kg DECIMAL(10,2),
  cost_dzd DECIMAL(12,2),
  status TEXT DEFAULT 'en_cours',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- IOT CAPTEURS
CREATE TABLE iot_sensors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sensor_code TEXT UNIQUE NOT NULL,
  type sensor_type NOT NULL,
  location TEXT NOT NULL,
  animal_id UUID REFERENCES animals(id),
  active BOOLEAN DEFAULT TRUE,
  threshold_min DECIMAL(10,4),
  threshold_max DECIMAL(10,4),
  unit TEXT
);

CREATE TABLE iot_readings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sensor_id UUID REFERENCES iot_sensors(id) ON DELETE CASCADE,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  value DECIMAL(12,4) NOT NULL,
  anomaly_flag BOOLEAN DEFAULT FALSE,
  anomaly_score DECIMAL(5,4)
);

-- ÉNERGIE SOLAIRE
CREATE TABLE solar_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL UNIQUE,
  kwh_produced DECIMAL(10,3),
  kwh_consumed DECIMAL(10,3),
  kwh_surplus DECIMAL(10,3),
  peak_power_kw DECIMAL(8,3),
  savings_dzd DECIMAL(12,2),
  autonomy_pct DECIMAL(5,2),
  weather_condition TEXT
);

-- VENTES
CREATE TABLE sales (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  date DATE NOT NULL,
  product_type product_type NOT NULL,
  quantity DECIMAL(10,3) NOT NULL,
  unit TEXT NOT NULL,
  unit_price_dzd DECIMAL(12,2) NOT NULL,
  total_dzd DECIMAL(14,2) NOT NULL,
  buyer_name TEXT,
  invoice_number TEXT,
  lot_ids UUID[],
  created_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ALERTES
CREATE TABLE alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  severity alert_severity NOT NULL,
  module alert_module NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  animal_id UUID REFERENCES animals(id),
  sensor_id UUID REFERENCES iot_sensors(id),
  ai_confidence DECIMAL(5,4),
  resolved BOOLEAN DEFAULT FALSE,
  resolved_by UUID REFERENCES profiles(id),
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TRAÇABILITÉ
CREATE TABLE traceability_lots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_number TEXT UNIQUE NOT NULL,
  lot_type product_type NOT NULL,
  animal_ids UUID[],
  creation_date DATE NOT NULL,
  slaughter_date DATE,
  certification_number TEXT,
  certifications TEXT[],
  veterinary_certificate TEXT,
  complete_history JSONB,
  qr_code_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AUDIT LOG
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id),
  action TEXT NOT NULL,
  table_name TEXT,
  record_id UUID,
  old_values JSONB,
  new_values JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- INDEX
CREATE INDEX idx_animals_status ON animals(status);
CREATE INDEX idx_animals_ear_tag ON animals(ear_tag);
CREATE INDEX idx_iot_readings_ts ON iot_readings(sensor_id, timestamp DESC);
CREATE INDEX idx_health_records_animal ON health_records(animal_id, date DESC);
CREATE INDEX idx_reproductions_female ON reproductions(female_id, status);
CREATE INDEX idx_alerts_active ON alerts(resolved, severity, created_at DESC);
CREATE INDEX idx_sales_date ON sales(date DESC);

-- RLS (Row Level Security)
ALTER TABLE animals ENABLE ROW LEVEL SECURITY;
ALTER TABLE health_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE iot_readings ENABLE ROW LEVEL SECURITY;
ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Politique animaux : tous les rôles sauf technicien IoT
CREATE POLICY "animals_access" ON animals FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','directeur','responsable_elevage','veterinaire'))
);

-- Politique IoT : admin, directeur, technicien
CREATE POLICY "iot_access" ON iot_readings FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','directeur','technicien_iot'))
);

-- Politique santé : admin, directeur, vétérinaire, responsable
CREATE POLICY "health_access" ON health_records FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','directeur','veterinaire','responsable_elevage'))
);

-- Politique ventes : admin, directeur uniquement
CREATE POLICY "sales_access" ON sales FOR ALL USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('admin','directeur'))
);

-- ============================================
-- DONNÉES SEED — Données démo réalistes
-- ============================================

-- Profils de nutrition
INSERT INTO feed_profiles (name, description, daily_ration_kg, cost_per_kg_dzd, ingredients) VALUES
('Brebis gestante 1er tiers', 'Gestation semaines 1-10', 1.8, 28.50, '[{"name":"Foin","qty_kg":1.0,"cost":15},{"name":"Orge concassée","qty_kg":0.5,"cost":9},{"name":"Fourrage hydroponique","qty_kg":0.2,"cost":3},{"name":"CMV ovin","qty_kg":0.1,"cost":1.5}]'),
('Brebis gestante dernier tiers', 'Gestation semaines 11-21', 2.1, 31.00, '[{"name":"Foin","qty_kg":1.1,"cost":16.5},{"name":"Orge","qty_kg":0.6,"cost":10.8},{"name":"Hydroponique","qty_kg":0.3,"cost":4.5},{"name":"CMV","qty_kg":0.1,"cost":1.5}]'),
('Brebis allaitante', 'Haute lactation 0-6 semaines', 2.4, 32.00, '[{"name":"Foin","qty_kg":1.2,"cost":18},{"name":"Orge","qty_kg":0.7,"cost":12.6},{"name":"Hydroponique","qty_kg":0.4,"cost":6},{"name":"CMV","qty_kg":0.1,"cost":1.5}]'),
('Agneau engraissement', 'Croissance 0-6 mois', 1.2, 35.00, '[{"name":"Foin","qty_kg":0.5,"cost":7.5},{"name":"Orge","qty_kg":0.4,"cost":7.2},{"name":"Hydroponique","qty_kg":0.3,"cost":4.5}]'),
('Bélier reproducteur', 'Entretien hors lutte', 2.0, 26.00, '[{"name":"Foin","qty_kg":1.4,"cost":21},{"name":"Orge","qty_kg":0.4,"cost":7.2},{"name":"Hydroponique","qty_kg":0.2,"cost":3}]'),
('Brebis entretien', 'Brebis non gestante', 1.5, 22.00, '[{"name":"Foin","qty_kg":1.2,"cost":18},{"name":"Orge","qty_kg":0.2,"cost":3.6},{"name":"Hydroponique","qty_kg":0.1,"cost":1.5}]');

-- Animaux (500 brebis + béliers)
INSERT INTO animals (ear_tag, rfid_tag, breed, sex, birth_date, pen_id, status, current_weight_kg, ai_risk_score, purchase_price_dzd) VALUES
('EOI-0001','RFID-001001','Ouled Djellal','F','2021-03-15','B-01','actif',62.5,8,38000),
('EOI-0002','RFID-001002','Ouled Djellal','F','2020-07-22','B-01','gestante',68.0,12,38000),
('EOI-0003','RFID-001003','Hamra','F','2022-01-10','B-02','allaitante',55.3,18,35000),
('EOI-0004','RFID-001004','Ouled Djellal','M','2019-11-05','B-02','actif',95.0,5,65000),
('EOI-0005','RFID-001005','Rembi','F','2021-06-18','B-03','gestante',58.7,22,32000),
('EOI-0006','RFID-001006','Ouled Djellal','F','2020-09-14','B-01','actif',61.2,10,38000),
('EOI-0007','RFID-001007','Hamra','F','2021-12-03','B-04','allaitante',52.8,14,35000),
('EOI-0008','RFID-001008','Ouled Djellal','F','2022-02-28','B-01','actif',58.1,6,38000),
('EOI-0009','RFID-001009','Rembi','M','2020-05-17','B-02','actif',88.5,8,60000),
('EOI-0010','RFID-001010','Ouled Djellal','F','2021-08-09','B-03','gestante',65.3,15,38000),
('EOI-0050','RFID-001050','Ouled Djellal','F','2020-11-20','B-01','actif',63.7,9,38000),
('EOI-0098','RFID-001098','Ouled Djellal','M','2022-01-15','B-02','actif',88.0,44,60000),
('EOI-0100','RFID-001100','Hamra','F','2021-04-05','B-04','gestante',57.4,19,35000),
('EOI-0150','RFID-001150','Rembi','F','2022-06-12','B-05','actif',49.8,7,32000),
('EOI-0189','RFID-001189','Hamra','F','2018-05-30','B-01','malade',52.1,71,35000),
('EOI-0200','RFID-001200','Ouled Djellal','F','2020-03-22','B-03','allaitante',60.5,16,38000),
('EOI-0247','RFID-001247','Ouled Djellal','F','2019-08-14','B-03','malade',48.2,82,38000),
('EOI-0300','RFID-001300','Hamra','F','2021-10-08','B-04','actif',56.9,11,35000),
('EOI-0312','RFID-001312','Rembi','M','2024-10-15','B-05','actif',22.4,58,0),
('EOI-0401','RFID-001401','Hamra','F','2023-01-20','B-04','actif',57.8,22,35000),
('EOI-0450','RFID-001450','Ouled Djellal','F','2022-09-18','B-01','gestante',64.1,13,38000),
('EOI-0500','RFID-001500','Rembi','F','2021-07-25','B-05','actif',51.3,9,32000);

-- Capteurs IoT
INSERT INTO iot_sensors (sensor_code, type, location, active, threshold_min, threshold_max, unit) VALUES
('T-BA-01','temperature','Bergerie A',TRUE,10,30,'°C'),
('T-BA-02','temperature','Bergerie A Zone 2',TRUE,10,30,'°C'),
('T-BB-01','temperature','Bergerie B',TRUE,10,30,'°C'),
('T-BB-02','temperature','Bergerie B Zone 2',TRUE,10,30,'°C'),
('T-BC-01','temperature','Bergerie C',TRUE,10,30,'°C'),
('H-BA-01','humidite','Bergerie A',TRUE,40,80,'%'),
('H-BB-01','humidite','Bergerie B',TRUE,40,80,'%'),
('H-BC-01','humidite','Bergerie C',TRUE,40,80,'%'),
('W-MAIN-01','eau_consommation','Réseau principal',TRUE,0,15000,'L/jour'),
('W-HYDRO-01','eau_consommation','Circuit hydroponique',TRUE,0,3000,'L/jour'),
('S-SOL-01','solaire_production','Toiture principale',TRUE,0,400,'kWh'),
('P-BAS-01','poids_bascule','Couloir pesée',TRUE,10,200,'kg'),
('CO2-BA-01','co2','Bergerie A',TRUE,400,2000,'ppm'),
('CO2-BB-01','co2','Bergerie B',TRUE,400,2000,'ppm'),
('ACT-BA-01','activite','Bergerie A',TRUE,0,100,'score'),
('ACT-BB-01','activite','Bergerie B',TRUE,0,100,'score');

-- Cycles hydroponiques
INSERT INTO hydro_cycles (cycle_number, start_date, expected_end_date, tray_count, seed_qty_kg, water_used_liters, yield_kg, cost_dzd, status) VALUES
(1,'2025-01-01','2025-01-08',840,42,2520,588,12600,'termine'),
(2,'2025-01-09','2025-01-16',840,42,2520,602,12600,'termine'),
(3,'2025-01-17','2025-01-24',840,42,2520,594,12600,'termine'),
(4,'2025-01-25','2025-02-01',840,42,2520,0,12600,'en_cours'),
(11,'2025-01-14','2025-01-22',1000,50,3000,0,15000,'en_cours');

-- Production solaire (30 derniers jours)
INSERT INTO solar_records (date, kwh_produced, kwh_consumed, kwh_surplus, peak_power_kw, savings_dzd, autonomy_pct, weather_condition)
SELECT
  CURRENT_DATE - i,
  ROUND((280 + random()*80)::numeric, 1),
  ROUND((185 + random()*30)::numeric, 1),
  ROUND((80 + random()*50)::numeric, 1),
  ROUND((62 + random()*18)::numeric, 2),
  ROUND((8400 + random()*2000)::numeric, 0),
  ROUND((80 + random()*18)::numeric, 2),
  CASE WHEN random() > 0.25 THEN 'ensoleillé' WHEN random() > 0.5 THEN 'partiellement nuageux' ELSE 'nuageux' END
FROM generate_series(0, 29) i;

-- Ventes
INSERT INTO sales (date, product_type, quantity, unit, unit_price_dzd, total_dzd, buyer_name, invoice_number) VALUES
('2025-01-15','viande_ovine',485.0,'kg',2800,1358000,'Abattoir SBA — M. Khelifa','FAC-2025-001'),
('2025-01-22','reproducteur_male',2,'tête',65000,130000,'Élevage Benali, Relizane','FAC-2025-002'),
('2025-01-28','fourrage',840,'kg',85,71400,'Éleveur local — M. Hadj Ahmed','FAC-2025-003'),
('2025-01-10','laine',120,'kg',450,54000,'Coopérative laine Oran','FAC-2025-004'),
('2024-12-10','viande_ovine',620,'kg',2750,1705000,'Abattoir Oran','FAC-2024-108'),
('2024-12-20','reproducteur_femelle',5,'tête',42000,210000,'Coopérative Mascara','FAC-2024-109'),
('2024-12-28','fourrage',1200,'kg',85,102000,'Collectivité locale SBA','FAC-2024-110'),
('2024-11-15','viande_ovine',540,'kg',2700,1458000,'Abattoir SBA','FAC-2024-089'),
('2024-11-25','fumier',5000,'kg',12,60000,'Agriculteur local','FAC-2024-090');

-- Alertes actives
INSERT INTO alerts (severity, module, title, message, ai_confidence) VALUES
('critique','ia','Brebis EOI-0247 — Score risque 82/100',
 'Analyse biométrique : fréquence respiratoire 28/min (normal 12-20), température 40.2°C, activité -65% sur 6h. Isolement recommandé sous 2h. Consultation vétérinaire urgente.',
 0.89),
('critique','iot','Température Bergerie B — 38.9°C',
 'Capteur T-BB-01 : dépassement du seuil maximum (30°C) depuis 32 minutes. Vérifier ventilation forcée et système de refroidissement. Risque de stress thermique pour 87 animaux.',
 0.97),
('modere','hydroponie','Stock fourrage critique — 2.8 jours',
 'Niveau de fourrage hydroponique sous le seuil de sécurité de 3 jours. Cycle C-12 à lancer immédiatement (840 plateaux disponibles). Stock estimé à 168 kg.',
 NULL),
('modere','sante','Rappel vaccination — Lot B-02',
 'Rappel annuel vaccin Pasteurellose + Entérotoxémie pour 38 animaux lot B-02. Délai dépassé de 3 jours. Contacter Dr. Benamara.',
 NULL),
('info','reproduction','6 agnelages attendus ce soir',
 'Lot G1 — 6 brebis en fin de gestation (J147-J149). Présence recommandée en bergerie à partir de 20h00. Score corporel moyen : 3.2/5.',
 0.78),
('info','energie','Production solaire optimale prévue demain',
 'Météo prévoit ensoleillement 9h. Production estimée 340-360 kWh. Planifier travaux électriques énergivores en journée.',
 0.72);

-- Records santé
INSERT INTO health_records (animal_id, type, date, diagnosis, treatment, medication, dosage, resolved, notes)
SELECT
  (SELECT id FROM animals WHERE ear_tag = 'EOI-0247'),
  'diagnostic',
  CURRENT_DATE,
  'Suspicion pneumonie — score risque IA 82/100',
  'Isolement en box individuel, monitoring toutes 2h',
  'En attente avis vétérinaire',
  NULL,
  FALSE,
  'Détecté par système IA à 09:28. Symptômes : toux légère, anorexie partielle, température 40.2°C'
;

INSERT INTO health_records (animal_id, type, date, diagnosis, treatment, medication, dosage, resolved, notes)
SELECT
  (SELECT id FROM animals WHERE ear_tag = 'EOI-0189'),
  'traitement',
  CURRENT_DATE - 2,
  'Boiterie pied droit — fourbure modérée',
  'Bain de pied, repos en box',
  'Sulfate de cuivre 5%',
  '2x / jour',
  FALSE,
  'Traitement débuté il y a 2 jours. Évolution favorable.'
;
