# 🐑 Élevage Ovin Intelligent — Guide de démarrage

## Étapes dans l'ordre

### 1. Installer les dépendances

Ouvrez cmd et tapez :

```
cd C:\Users\ASUS\Desktop\elevage-ovin
npm install
```

### 2. Créer votre compte Supabase

1. Allez sur https://supabase.com
2. Cliquez "Start your project"
3. Créez un projet nommé "elevage-ovin"
4. Région : EU West
5. Attendez 2 minutes que le projet se crée

### 3. Récupérer vos clés Supabase

1. Dans Supabase → Settings → API
2. Copiez "Project URL" et "anon public key"

### 4. Configurer le fichier .env.local

Créez un fichier ".env.local" dans le dossier elevage-ovin :

```
NEXT_PUBLIC_SUPABASE_URL=https://VOTRE_ID.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=votre_cle_ici
```

### 5. Créer la base de données

1. Dans Supabase → SQL Editor
2. Copiez tout le contenu de supabase/migrations/001_schema_seed.sql
3. Collez dans SQL Editor
4. Cliquez "Run"

### 6. Lancer le projet

```
npm run dev
```

Ouvrez http://localhost:3000

### 7. Créer un utilisateur admin

1. Dans Supabase → Authentication → Users
2. Cliquez "Invite user"
3. Entrez votre email
4. Dans SQL Editor, exécutez :

```sql
INSERT INTO profiles (id, full_name, role)
VALUES (
  (SELECT id FROM auth.users WHERE email = 'votre@email.com'),
  'Directeur Général',
  'admin'
);
```

## En cas de problème

- Erreur "Module not found" → relancez : npm install
- Page blanche → vérifiez .env.local
- Erreur Supabase → vérifiez vos clés API

## Support

Consultez la documentation sur https://supabase.com/docs
